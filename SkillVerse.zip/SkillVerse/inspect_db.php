<?php
require_once __DIR__ . '/config/db.php';
$pdo = getDBConnection();
echo "--- USERS ---\n";
$users = $pdo->query("SELECT id, full_name, email, avatar FROM users")->fetchAll();
print_r($users);

echo "--- SKILLS ---\n";
$skills = $pdo->query("SELECT id, user_id, title, category FROM skills")->fetchAll();
print_r($skills);

echo "--- USER SKILL TAGS ---\n";
$tags = $pdo->query("SELECT id, user_id, skill_name, tag_type FROM user_skill_tags")->fetchAll();
print_r($tags);
