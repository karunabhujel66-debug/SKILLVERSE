<?php
/**
 * GET users=1  → list of students you can message
 * GET receiver_id=ID → conversation JSON between you and that user
 */

require_once __DIR__ . '/config/mysqli.php';

$userId = chatRequireLogin();
$db = getMysqli();

if (isset($_GET['users']) && $_GET['users'] == '1') {
    $users = [];
    $sql = "
        SELECT id, full_name, avatar, university, tagline
        FROM users
        WHERE id != $userId
        ORDER BY full_name ASC
    ";
    $res = $db->query($sql);
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $users[] = $row;
        }
    }
    chatJson([
        'success' => true,
        'users'   => $users
    ]);
}

$receiverId = isset($_GET['receiver_id']) ? (int)$_GET['receiver_id'] : 0;
$partnerName = isset($_GET['partner_name']) ? trim($_GET['partner_name']) : '';

if ($receiverId <= 0 && $partnerName !== '') {
    $like = '%' . $db->real_escape_string($partnerName) . '%';
    $res = $db->query("SELECT id FROM users WHERE full_name LIKE '$like' OR email LIKE '$like' LIMIT 1");
    if ($res && $row = $res->fetch_assoc()) {
        $receiverId = (int)$row['id'];
    }
}

if ($receiverId <= 0) {
    chatJson(['success' => false, 'error' => 'Missing receiver_id.']);
}

$partner = null;
$pRes = $db->query("SELECT id, full_name, avatar, tagline FROM users WHERE id = $receiverId LIMIT 1");
if ($pRes) {
    $partner = $pRes->fetch_assoc();
}

$messages = [];
$q = "
    SELECT
        id,
        sender_id,
        receiver_id,
        message,
        created_at,
        CASE WHEN sender_id = $userId THEN 'sent' ELSE 'received' END AS direction
    FROM messages
    WHERE (sender_id = $userId AND receiver_id = $receiverId)
       OR (sender_id = $receiverId AND receiver_id = $userId)
    ORDER BY id ASC
";
$mRes = $db->query($q);
if ($mRes) {
    while ($row = $mRes->fetch_assoc()) {
        $messages[] = $row;
    }
}

$db->query("UPDATE messages SET is_read = 1 WHERE sender_id = $receiverId AND receiver_id = $userId");

chatJson([
    'success'  => true,
    'partner'  => $partner,
    'messages' => $messages
]);
