<?php
/**
 * Return unread notification count + recent notifications (JSON).
 */

require_once __DIR__ . '/config/mysqli.php';

$userId = chatRequireLogin();
$db = getMysqli();

$unreadCount = 0;
$cRes = $db->query("SELECT COUNT(*) AS c FROM notifications WHERE user_id = $userId AND is_read = 0");
if ($cRes && $row = $cRes->fetch_assoc()) {
    $unreadCount = (int)$row['c'];
}

$notifications = [];
$nRes = $db->query("
    SELECT id, title, message, icon, is_read, created_at
    FROM notifications
    WHERE user_id = $userId
    ORDER BY id DESC
    LIMIT 20
");

if ($nRes) {
    while ($n = $nRes->fetch_assoc()) {
        $n['text'] = $n['message'];
        $n['unread'] = ((int)$n['is_read'] === 0);
        $n['time'] = $n['created_at'];
        $notifications[] = $n;
    }
}

chatJson([
    'success'       => true,
    'count'         => $unreadCount,
    'unreadCount'   => $unreadCount,
    'notifications' => $notifications
]);
