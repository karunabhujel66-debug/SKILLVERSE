-- ==============================================================================
-- Skillverse Database Schema & Seed Data (MySQL / XAMPP)
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS `skillverse_db` 
  DEFAULT CHARACTER SET utf8mb4 
  COLLATE utf8mb4_unicode_ci;

USE `skillverse_db`;

-- Drop existing tables in correct order if re-initializing
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `messages`;
DROP TABLE IF EXISTS `exchanges_history`;
DROP TABLE IF EXISTS `exchange_requests`;
DROP TABLE IF EXISTS `user_skill_tags`;
DROP TABLE IF EXISTS `skills`;
DROP TABLE IF EXISTS `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- ==============================================================================
-- 1. USERS TABLE
-- ==============================================================================
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `university` VARCHAR(150) NOT NULL DEFAULT 'University of Technology',
  `tagline` VARCHAR(255) DEFAULT 'Student & Lifelong Learner',
  `bio` TEXT,
  `avatar` VARCHAR(255) DEFAULT 'assets/alex_chen.jpg',
  `phone` VARCHAR(50) DEFAULT NULL,
  `phone_number` VARCHAR(20) DEFAULT NULL,
  `messenger_username` VARCHAR(100) DEFAULT NULL,
  `instagram_username` VARCHAR(100) DEFAULT NULL,
  `facebook_url` VARCHAR(255) DEFAULT NULL,
  `rating` DECIMAL(3,1) NOT NULL DEFAULT 5.0,
  `hours_taught` INT NOT NULL DEFAULT 0,
  `hours_learned` INT NOT NULL DEFAULT 0,
  `exchanges_count` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 2. SKILLS TABLE (Marketplace listings)
-- ==============================================================================
CREATE TABLE `skills` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `category` ENUM('Development', 'Design', 'Photography', 'Business', 'Language', 'Music & Audio', 'Other') NOT NULL DEFAULT 'Development',
  `mastery_level` ENUM('Beginner', 'Intermediate', 'Advanced', 'Expert') NOT NULL DEFAULT 'Intermediate',
  `description` TEXT NOT NULL,
  `image` VARCHAR(255) NOT NULL DEFAULT 'assets/web_design.jpg',
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_skill_category` (`category`),
  INDEX `idx_skill_user` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 3. USER SKILL TAGS TABLE (Profile tags: Teach / Learn)
-- ==============================================================================
CREATE TABLE `user_skill_tags` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `skill_name` VARCHAR(100) NOT NULL,
  `tag_type` ENUM('teach', 'learn') NOT NULL DEFAULT 'teach',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_tag_user` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 4. EXCHANGE REQUESTS TABLE
-- ==============================================================================
CREATE TABLE `exchange_requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `sender_id` INT NOT NULL,
  `receiver_id` INT NOT NULL,
  `target_skill_title` VARCHAR(150) NOT NULL,
  `offered_skill_title` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `status` ENUM('pending', 'accepted', 'declined', 'completed') NOT NULL DEFAULT 'pending',
  `scheduled_date` DATETIME NULL,
  `scheduled_platform` VARCHAR(100) NULL,
  `scheduled_notes` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_req_receiver` (`receiver_id`),
  INDEX `idx_req_sender` (`sender_id`),
  FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 5. MESSAGES TABLE (Live peer chat)
-- ==============================================================================
CREATE TABLE `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `sender_id` INT NOT NULL,
  `receiver_id` INT NOT NULL,
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_msg_users` (`sender_id`, `receiver_id`),
  FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 6. NOTIFICATIONS TABLE
-- ==============================================================================
CREATE TABLE `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `message` TEXT NOT NULL,
  `icon` VARCHAR(20) NOT NULL DEFAULT '🔔',
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_notif_user` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 7. EXCHANGES HISTORY TABLE
-- ==============================================================================
CREATE TABLE `exchanges_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `partner_id` INT NOT NULL,
  `topic` VARCHAR(150) NOT NULL,
  `type` ENUM('taught', 'learned') NOT NULL DEFAULT 'taught',
  `date_completed` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_exchange_user` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`partner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- INITIAL SEED DATA
-- Default password for all users: 'password123'
-- ==============================================================================

INSERT INTO `users` (`id`, `full_name`, `email`, `password_hash`, `university`, `tagline`, `bio`, `avatar`, `phone`, `facebook_url`, `rating`, `hours_taught`, `hours_learned`, `exchanges_count`, `created_at`) VALUES
(1, 'Alex Chen', 'student@university.edu', '$2y$10$wSj1Oq69eM3UvhU7XyG/d.2P12Y7jG5kCvhz3PsmNlWpE4h4fQ9K6', 'Stanford University', 'Computer Science Major • 3rd Year • Tech Enthusiast', 'Hey! I\'m Alex. I love building things with code and helping others figure out tricky bugs. Always looking to trade my programming knowledge for some design tips or maybe even some guitar lessons. Let\'s learn together!', 'assets/alex_chen.jpg', '+1 (555) 234-5678', 'https://facebook.com/alexchen.tech', 4.9, 45, 32, 24, NOW() - INTERVAL 30 DAY),
(2, 'Sarah Jenkins', 'sarah.j@university.edu', '$2y$10$wSj1Oq69eM3UvhU7XyG/d.2P12Y7jG5kCvhz3PsmNlWpE4h4fQ9K6', 'Rhode Island School of Design', 'UX/UI Design & Digital Arts • 3rd Year', 'Passionate about Figma, prototyping, and micro-interactions. Excited to help coders make their apps look gorgeous!', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80', '+1 (555) 345-6789', 'https://facebook.com/sarah.jenkins.design', 5.0, 38, 20, 18, NOW() - INTERVAL 25 DAY),
(3, 'David Okafor', 'david.o@university.edu', '$2y$10$wSj1Oq69eM3UvhU7XyG/d.2P12Y7jG5kCvhz3PsmNlWpE4h4fQ9K6', 'NYU Stern School of Business', 'Finance & Business Analytics • 1st Year', 'Data analytics fanatic. I build financial models, SQL queries, and Excel automation macros.', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80', '+1 (555) 456-7890', 'https://facebook.com/david.okafor.data', 4.8, 22, 15, 12, NOW() - INTERVAL 20 DAY),
(4, 'Carlos Mendez', 'carlos.m@university.edu', '$2y$10$wSj1Oq69eM3UvhU7XyG/d.2P12Y7jG5kCvhz3PsmNlWpE4h4fQ9K6', 'UC Berkeley', 'Modern Languages & Linguistics • 4th Year', 'Native Spanish speaker and language enthusiast. Let\'s practice conversational fluency over virtual coffee.', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80', '+1 (555) 567-8901', 'https://facebook.com/carlos.mendez.lang', 4.9, 50, 40, 30, NOW() - INTERVAL 15 DAY),
(5, 'Sam Taylor', 'sam.t@university.edu', '$2y$10$wSj1Oq69eM3UvhU7XyG/d.2P12Y7jG5kCvhz3PsmNlWpE4h4fQ9K6', 'Columbia University', 'Visual Arts & Film Production • 2nd Year', 'Photographer with a love for analog film, lighting composition, and darkroom developing.', 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=120&auto=format&fit=crop&q=80', '+1 (555) 678-9012', 'https://facebook.com/sam.taylor.photo', 4.7, 19, 14, 9, NOW() - INTERVAL 10 DAY);

-- SEED SKILLS
INSERT INTO `skills` (`id`, `user_id`, `title`, `category`, `mastery_level`, `description`, `image`, `is_featured`, `created_at`) VALUES
(1, 2, 'Web Design Basics', 'Design', 'Intermediate', 'Learn the fundamentals of layout, color theory, and typography to create stunning web interfaces.', 'assets/web_design.jpg', 0, NOW() - INTERVAL 5 DAY),
(2, 3, 'Advanced React Patterns', 'Development', 'Advanced', 'Dive deep into hooks, context, and state management for scalable applications.', 'assets/react_patterns.jpg', 1, NOW() - INTERVAL 4 DAY),
(3, 5, 'Film Photography', 'Photography', 'Intermediate', 'Master the art of 35mm film, from loading the camera to developing prints.', 'assets/film_photography.jpg', 0, NOW() - INTERVAL 3 DAY),
(4, 3, 'Intro to Data Analytics', 'Business', 'Advanced', 'Learn how to extract insights from raw data using modern tools, SQL, and Excel pivots.', 'assets/data_analytics.jpg', 0, NOW() - INTERVAL 2 DAY),
(5, 1, 'Python Programming Essentials', 'Development', 'Expert', 'Data structures, algorithm practice, and scripting for modern software development.', 'assets/collab_hero.jpg', 0, NOW() - INTERVAL 1 DAY),
(6, 4, 'Conversational Spanish', 'Language', 'Expert', 'Interactive conversational Spanish practice for beginners and intermediate learners.', 'assets/collab_hero.jpg', 0, NOW() - INTERVAL 12 HOUR);

-- SEED USER SKILL TAGS (For Alex Chen, user_id=1)
INSERT INTO `user_skill_tags` (`user_id`, `skill_name`, `tag_type`) VALUES
(1, 'Python ✓', 'teach'),
(1, 'React ✓', 'teach'),
(1, 'Data Structures', 'teach'),
(1, 'Calculus', 'teach'),
(1, 'UI/UX Design', 'learn'),
(1, 'Figma', 'learn'),
(1, 'Spanish (Conversational)', 'learn'),
(2, 'Figma ✓', 'teach'),
(2, 'Wireframing', 'teach'),
(2, 'Python', 'learn'),
(3, 'SQL ✓', 'teach'),
(3, 'Excel Macros', 'teach'),
(3, 'React Patterns', 'learn');

-- SEED EXCHANGE REQUESTS (Incoming to Alex Chen, receiver_id=1)
INSERT INTO `exchange_requests` (`id`, `sender_id`, `receiver_id`, `target_skill_title`, `offered_skill_title`, `message`, `status`, `created_at`) VALUES
(1, 5, 1, 'Python Basics', 'Film Photography', 'Hi! I saw your profile and would love some help understanding loops and lists for my upcoming homework assignment.', 'pending', NOW() - INTERVAL 2 HOUR),
(2, 2, 1, 'React State Management', 'Figma Prototyping', 'I\'m struggling with interactive components in my final project. Could we do a quick session this Friday?', 'pending', NOW() - INTERVAL 5 HOUR),
(3, 3, 1, 'Data Structures & Algorithms', 'Excel Macros', 'Need to automate some financial reports for my internship prep. Heard you\'re a wizard!', 'pending', NOW() - INTERVAL 1 DAY);

-- SEED NOTIFICATIONS (For Alex Chen, user_id=1)
INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `icon`, `is_read`, `created_at`) VALUES
(1, 1, 'New Exchange Request', 'Sarah Jenkins sent you a skill exchange request for Figma Prototyping.', '💡', 0, NOW() - INTERVAL 5 HOUR),
(2, 1, 'Session Request', 'Sam Taylor requested a session for Python Basics.', '🎓', 0, NOW() - INTERVAL 2 HOUR),
(3, 1, 'Exchange Request', 'David Okafor sent you a request for Excel Macros.', '📊', 0, NOW() - INTERVAL 1 DAY),
(4, 1, 'Session Completed', 'Your exchange session with Sarah M. was marked completed (+1.5h taught).', '⭐', 1, NOW() - INTERVAL 2 DAY);

-- SEED MESSAGES (Between Alex Chen id=1 and Sarah Jenkins id=2)
INSERT INTO `messages` (`sender_id`, `receiver_id`, `message`, `is_read`, `created_at`) VALUES
(2, 1, 'Hi Alex! Excited for our exchange session this week.', 1, NOW() - INTERVAL 3 HOUR),
(1, 2, 'Hey Sarah! Me too, got Figma ready!', 1, NOW() - INTERVAL 2 HOUR);

-- SEED EXCHANGES HISTORY (For Alex Chen)
INSERT INTO `exchanges_history` (`user_id`, `partner_id`, `topic`, `type`, `date_completed`) VALUES
(1, 2, 'Intro to React Hooks', 'taught', NOW() - INTERVAL 2 DAY),
(1, 3, 'Figma Component Basics', 'learned', NOW() - INTERVAL 7 DAY),
(1, 4, 'Python Debugging Session', 'taught', NOW() - INTERVAL 14 DAY);
