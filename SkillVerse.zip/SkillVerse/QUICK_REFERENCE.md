# Skillverse Platform Update - Quick Reference Guide

## 🎉 What's New

Your Student Skill Exchange Platform now has three major features:

### 1. 📞 Social Media Contact Buttons
Click to message instructors directly via WhatsApp, Messenger, or Instagram

### 2. 📸 Required Skill Images  
All skills must have an image (jpg, jpeg, png, max 5MB)

### 3. 👤 Profile Contact Fields
Save your WhatsApp, Messenger, and Instagram info for students to contact you

---

## 🚀 For Users

### Adding a Skill

**Step 1: Upload Image**
- Click "Share Skill" button
- Select image file (JPG/PNG, under 5MB)
- See preview before uploading

**Step 2: Fill Details**
- Title: "Python Programming" ✓
- Description: "Learn Python basics..." ✓
- Category: Choose one ✓
- Mastery Level: Choose one ✓

**Step 3: Publish**
- Click "Share Skill"
- Image is automatically uploaded
- Skill appears in Browse with your contact buttons

### Updating Your Profile

**Contact Information:**
1. Go to Profile → Edit Profile
2. Add your contact details:
   - **WhatsApp:** Your phone number (+1-555-1234567)
   - **Messenger:** Your Facebook username (john.doe)
   - **Instagram:** Your Instagram username (johndoe_official)
3. Save changes
4. Your contact buttons appear on all your skills

### Finding & Contacting Instructors

1. Browse skills on the platform
2. Find the skill you want to learn
3. See instructor's contact section:
   - 💬 WhatsApp - Click to open WhatsApp
   - 💙 Messenger - Click to open Messenger
   - 📷 Instagram - Click to view profile
4. Message directly to arrange learning

---

## 🔧 For Developers

### API Endpoints

#### Upload Image
```bash
POST /api/upload_skill_image.php
Content-Type: multipart/form-data

File: <image file (jpg/jpeg/png, max 5MB)>
```

**Response:**
```json
{
  "success": true,
  "file_path": "uploads/skill_1_1693456789_abc123.jpg"
}
```

#### Create Skill (with image required)
```bash
POST /api/skills.php
Content-Type: application/json

{
  "title": "Python",
  "description": "Learn Python",
  "category": "Development",
  "masteryLevel": "Advanced",
  "image": "uploads/skill_1_1693456789_abc123.jpg"
}
```

#### Update Profile (new contact fields)
```bash
POST /api/profile.php?action=update
Content-Type: application/json

{
  "full_name": "John Doe",
  "phone_number": "+15551234567",
  "messenger_username": "john.doe",
  "instagram_username": "johndoe_official",
  "facebook_url": "https://facebook.com/johndoe"
}
```

#### Get Skills (with contact info)
```bash
GET /api/skills.php
```

**Response includes:**
```json
{
  "instructor": "John Doe",
  "instructorPhoneNumber": "+15551234567",
  "instructorMessenger": "john.doe",
  "instructorInstagram": "johndoe_official",
  "instructorFacebook": "https://facebook.com/johndoe"
}
```

### Database Schema

**New columns in users table:**
```sql
phone_number VARCHAR(20) - WhatsApp number
messenger_username VARCHAR(100) - Messenger username
instagram_username VARCHAR(100) - Instagram username
```

**Auto-migration:** Runs automatically on first connection

### File Locations

| File | Purpose |
|------|---------|
| `/api/upload_skill_image.php` | Image upload handler |
| `/api/skills.php` | Skill management (updated) |
| `/api/profile.php` | Profile updates (updated) |
| `/config/db.php` | Database connection (updated) |
| `/database/schema.sql` | Database schema (updated) |
| `/uploads/` | Skill images stored here |

### Validation Rules

**Image Upload:**
- ✓ Required (no empty uploads)
- ✓ Only JPG, JPEG, PNG
- ✓ Maximum 5MB

**Skill Creation:**
- ✓ Title required
- ✓ Description required
- ✓ Image required

**Profile:**
- ✓ Phone number: format +1-555-1234567
- ✓ Messenger: username only (john.doe)
- ✓ Instagram: username without @ (johndoe_official)

---

## 📚 Documentation Files

| File | Description |
|------|-------------|
| `UPDATE_SUMMARY.md` | Complete overview & API details |
| `IMPLEMENTATION_GUIDE.md` | HTML/CSS/JS implementation examples |
| `PHP_CHANGES_SUMMARY.php` | PHP code changes & validation logic |
| `QUICK_REFERENCE.md` | This file |

---

## 🧪 Testing

### Test Image Upload
```javascript
const formData = new FormData();
formData.append('image', fileInput.files[0]);
fetch('/api/upload_skill_image.php', { method: 'POST', body: formData });
```

### Test Skill Creation
```javascript
fetch('/api/skills.php', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    title: 'Python',
    description: 'Learn Python',
    category: 'Development',
    masteryLevel: 'Intermediate',
    image: 'uploads/skill_1_1693456789.jpg'
  })
});
```

### Test Contact Links
- WhatsApp: `https://wa.me/15551234567`
- Messenger: `https://m.me/john.doe`
- Instagram: `https://instagram.com/johndoe_official`

---

## ✅ Checklist for Implementation

- [ ] Database auto-migration completed (or run setup.php)
- [ ] `/uploads/` directory created with write permissions
- [ ] Upload form with image input added to UI
- [ ] Image preview functionality working
- [ ] Skill form validates: title, description, image required
- [ ] Profile form includes 4 new contact fields
- [ ] Contact buttons render on skill cards
- [ ] Contact links tested on mobile
- [ ] Error messages display clearly
- [ ] File upload limits enforced (5MB, jpg/jpeg/png only)

---

## 🐛 Troubleshooting

### Image upload fails
- Check `/uploads/` directory exists
- Verify directory has write permissions (chmod 755)
- Confirm file is jpg/jpeg/png
- Ensure file size under 5MB

### Contact buttons don't appear
- Verify profile has contact information saved
- Check browser console for JavaScript errors
- Ensure CSS is loaded for button styling

### Database columns missing
- Run database setup: open `setup.php` in browser
- Or API auto-creates columns on first connection
- Check with: `SHOW COLUMNS FROM users;`

### Skills won't save without image
- This is by design - image is now required
- Must upload image first via upload_skill_image.php
- Use returned file_path in skill creation

---

## 📱 Mobile Compatibility

| Feature | Mobile | Desktop |
|---------|--------|---------|
| WhatsApp Button | ✓ Opens app | ✓ Opens Web |
| Messenger Button | ✓ Opens app | ✓ Opens Web |
| Instagram Button | ✓ Opens app | ✓ Opens Web |
| Image Upload | ✓ File picker | ✓ File picker/drag |
| Profile Edit | ✓ Full form | ✓ Full form |

---

## 🔐 Security Features

- ✓ File type validation (server-side)
- ✓ File size limits (5MB max)
- ✓ Unique filenames (prevent conflicts)
- ✓ User authentication required
- ✓ Server-side validation (not just client-side)

---

## 📊 Database Schema Changes

```sql
-- Run automatically or manually:
ALTER TABLE `users` 
ADD COLUMN `phone_number` VARCHAR(20) DEFAULT NULL,
ADD COLUMN `messenger_username` VARCHAR(100) DEFAULT NULL,
ADD COLUMN `instagram_username` VARCHAR(100) DEFAULT NULL;
```

---

## 🎓 Example Workflow

**Student A (John) wants to teach Python:**

1. John creates skill "Python Programming"
2. System asks for image → John uploads python.jpg
3. John fills in: title, description, category, mastery level
4. John clicks "Share Skill" → Published to Browse

**John updates his profile:**

1. John goes to Edit Profile
2. Adds contact info:
   - Phone: +1-555-8901234 (WhatsApp)
   - Messenger: john.doe
   - Instagram: johndoe_official
3. Saves profile
4. Contact buttons now appear on his skills

**Student B (Sarah) wants to learn Python:**

1. Sarah browses skills → finds "Python Programming" by John
2. Sarah sees John's contact section with 3 buttons
3. Sarah clicks WhatsApp → opens WhatsApp Web/App
4. Sarah messages John to arrange session

---

## 🚀 Deployment Notes

1. **Database:** Auto-migration runs on first API call
2. **Uploads:** Ensure `/uploads/` directory writable
3. **Images:** Stored with unique names (no overwrites)
4. **Validation:** Happens both client-side and server-side
5. **Security:** File types restricted, sizes limited

---

## 📞 Questions?

Check the comprehensive guides:
- `UPDATE_SUMMARY.md` - Full overview
- `IMPLEMENTATION_GUIDE.md` - Code examples
- `PHP_CHANGES_SUMMARY.php` - Technical details

---

**Last Updated:** August 31, 2026  
**Platform Version:** 2.0  
**Status:** ✅ Production Ready

*All features implemented with simple PHP (no frameworks), secure validation, and mobile-friendly design.*
