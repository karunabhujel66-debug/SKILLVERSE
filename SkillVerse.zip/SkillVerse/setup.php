<?php
/**
 * Skillverse Automated Database Setup & Installer
 * Works both via Browser (http://localhost/SkillVerse/setup.php) and CLI (php setup.php)
 */

$host = '127.0.0.1';
$port = '3306';
$user = 'root';
$dbName = 'skillverse_db';
$passwordsToTry = ['root', ''];

$isCli = (php_sapi_name() === 'cli');
$results = [];
$error = null;
$success = false;

if (!$isCli && $_SERVER['REQUEST_METHOD'] === 'POST' || $isCli || isset($_GET['auto'])) {
    try {
        $pdo = null;
        $connectedPass = '';
        foreach ($passwordsToTry as $pass) {
            try {
                $pdo = new PDO("mysql:host=$host;port=$port;charset=utf8mb4", $user, $pass, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
                ]);
                $connectedPass = $pass;
                break;
            } catch (Exception $ex) {
                // try next
            }
        }

        if (!$pdo) {
            throw new Exception("Could not connect to MySQL server ($host:$port) with user '$user'. Please ensure MySQL is running in XAMPP.");
        }

        $results[] = " Connected to MySQL server successfully ($host:$port).";

        // Step 2: Read schema file
        $schemaPath = __DIR__ . '/database/schema.sql';
        if (!file_exists($schemaPath)) {
            throw new Exception("schema.sql not found at: $schemaPath");
        }
        $sql = file_get_contents($schemaPath);
        $results[] = " Loaded database schema from database/schema.sql.";

        // Step 3: Execute SQL queries
        $pdo->exec($sql);
        $results[] = " Created database `$dbName` and executed all table schemas & initial seed data.";

        // Step 4: Verify counts
        $db = new PDO("mysql:host=$host;port=$port;dbname=$dbName;charset=utf8mb4", $user, $connectedPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);

        $userCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $skillCount = $db->query("SELECT COUNT(*) FROM skills")->fetchColumn();
        $reqCount = $db->query("SELECT COUNT(*) FROM exchange_requests")->fetchColumn();
        $notifCount = $db->query("SELECT COUNT(*) FROM notifications")->fetchColumn();

        $results[] = " Verified tables: $userCount users, $skillCount skills, $reqCount exchange requests, $notifCount notifications initialized.";
        $success = true;
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

if ($isCli) {
    echo "========================================\n";
    echo "  SKILLVERSE DATABASE INSTALLER (CLI)   \n";
    echo "========================================\n";
    foreach ($results as $res) {
        echo "[OK] " . $res . "\n";
    }
    if ($error) {
        echo "[ERROR] " . $error . "\n";
        exit(1);
    }
    echo "[SUCCESS] Skillverse database is completely set up!\n";
    exit(0);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Skillverse - Database Setup & Installer</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🌱</text></svg>" />
  <style>
    :root {
      --bg: #F4F7F4;
      --card-bg: #FFFFFF;
      --primary: #1C3829;
      --accent: #2E7D32;
      --mint: #E8F5E9;
      --text: #1E293B;
      --text-muted: #64748B;
      --border: #E2E8F0;
      --success: #15803D;
      --danger: #DC2626;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
    body {
      background-color: var(--bg);
      color: var(--text);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 1.5rem;
    }
    .setup-card {
      background: var(--card-bg);
      border-radius: 16px;
      box-shadow: 0 10px 35px rgba(0,0,0,0.06);
      width: 100%;
      max-width: 620px;
      padding: 2.5rem;
      border: 1px solid var(--border);
    }
    .header {
      text-align: center;
      margin-bottom: 2rem;
    }
    .logo-badge {
      font-size: 2.4rem;
      display: inline-block;
      margin-bottom: 0.5rem;
    }
    h1 {
      font-size: 1.7rem;
      font-weight: 800;
      color: var(--primary);
    }
    p.subtitle {
      color: var(--text-muted);
      font-size: 0.95rem;
      margin-top: 0.3rem;
    }
    .status-box {
      border-radius: 12px;
      padding: 1.25rem;
      margin-bottom: 1.5rem;
      font-size: 0.92rem;
      line-height: 1.6;
    }
    .status-box.success {
      background-color: #F0FDF4;
      border: 1px solid #BBF7D0;
      color: var(--success);
    }
    .status-box.error {
      background-color: #FEF2F2;
      border: 1px solid #FECACA;
      color: var(--danger);
    }
    .results-list {
      list-style: none;
      margin-bottom: 1.5rem;
    }
    .results-list li {
      padding: 0.6rem 0.8rem;
      margin-bottom: 0.5rem;
      border-radius: 8px;
      background: #F8FAFC;
      border: 1px solid #E2E8F0;
      font-size: 0.88rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      width: 100%;
      padding: 0.9rem 1.5rem;
      border-radius: 10px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.2s ease;
      border: none;
    }
    .btn-primary {
      background-color: var(--primary);
      color: #FFF;
    }
    .btn-primary:hover {
      background-color: #14281E;
      transform: translateY(-1px);
    }
    .btn-outline {
      background: transparent;
      border: 1.5px solid var(--border);
      color: var(--text);
      margin-top: 0.8rem;
    }
    .btn-outline:hover {
      background: #F1F5F9;
    }
    .credentials-card {
      background: #F8FAFC;
      border-radius: 10px;
      padding: 1rem;
      margin: 1.5rem 0;
      border: 1px dashed #CBD5E1;
      font-size: 0.86rem;
    }
    .credentials-card strong {
      color: var(--primary);
    }
  </style>
</head>
<body>

  <div class="setup-card">
    <div class="header">
      <div class="logo-badge">🌱</div>
      <h1>Skillverse Database Installer</h1>
      <p class="subtitle">Quick setup for MySQL / XAMPP local environment</p>
    </div>

    <?php if ($success): ?>
      <div class="status-box success">
        <strong> Database Initialized Successfully!</strong>
        <p>All database tables, constraints, and realistic student seed data are ready.</p>
      </div>

      <ul class="results-list">
        <?php foreach ($results as $res): ?>
          <li><span>✅</span> <?php echo htmlspecialchars($res); ?></li>
        <?php endforeach; ?>
      </ul>

      <div class="credentials-card">
        <strong>Demo Login Accounts:</strong><br>
        • <strong>student@university.edu</strong> / <strong>password123</strong> (Alex Chen)<br>
        • <strong>sarah.j@university.edu</strong> / <strong>password123</strong> (Sarah Jenkins)<br>
        • <strong>david.o@university.edu</strong> / <strong>password123</strong> (David Okafor)
      </div>

      <a href="index.html" class="btn btn-primary">Open Skillverse App →</a>

    <?php else: ?>
      <?php if ($error): ?>
        <div class="status-box error">
          <strong>❌ Database Connection Error</strong>
          <p><?php echo htmlspecialchars($error); ?></p>
          <p style="margin-top: 0.5rem; font-size: 0.84rem;">
            <em>Troubleshooting Tip:</em> Ensure XAMPP is running and the <strong>MySQL</strong> service is started on port 3306.
          </p>
        </div>
      <?php endif; ?>

      <p style="margin-bottom: 1.5rem; font-size: 0.92rem; color: var(--text-muted); line-height: 1.5;">
        This tool will automatically create the <code>skillverse_db</code> database, import all normalized tables (users, skills, exchange requests, live messages, notifications), and populate demo accounts.
      </p>

      <form method="POST">
        <button type="submit" class="btn btn-primary">⚡ Initialize & Seed Database</button>
      </form>
      <a href="index.html" class="btn btn-outline">Back to Application</a>
    <?php endif; ?>
  </div>

</body>
</html>
