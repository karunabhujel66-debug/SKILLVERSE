<?php
/**
 * SKILLVERSE UPDATE SUMMARY - PHP CODE CHANGES
 * All modifications made to implement:
 * 1. Social Media Contact Buttons (WhatsApp, Messenger, Instagram)
 * 2. Compulsory Skill Image Upload
 * 3. PHP-based File Validation
 * 4. Profile Contact Information Fields
 */

// ============================================================================
// FILE 1: /api/upload_skill_image.php (NEW FILE)
// ============================================================================
/*
<?php
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('POST request required.', 405);
}

$userId = requireAuth();

if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    jsonError('Image is required for skill upload', 400);
}

$file = $_FILES['image'];
$fileName = $file['name'];
$fileTmp = $file['tmp_name'];
$fileSize = $file['size'];

// Only jpg, jpeg, png allowed
$allowedExtensions = ['jpg', 'jpeg', 'png'];
$fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

if (!in_array($fileExtension, $allowedExtensions)) {
    jsonError('Only JPG, JPEG, and PNG files are allowed.', 400);
}

// Max 5MB
$maxFileSize = 5 * 1024 * 1024;
if ($fileSize > $maxFileSize) {
    jsonError('File size must not exceed 5MB.', 400);
}

// Create uploads directory
$uploadsDir = __DIR__ . '/../uploads/';
if (!is_dir($uploadsDir)) {
    mkdir($uploadsDir, 0755, true);
}

// Generate unique filename
$uniqueId = uniqid('skill_' . $userId . '_' . time() . '_', true);
$newFileName = $uniqueId . '.' . $fileExtension;
$uploadPath = $uploadsDir . $newFileName;

if (!move_uploaded_file($fileTmp, $uploadPath)) {
    jsonError('Failed to save uploaded file.', 500);
}

jsonResponse([
    'success' => true,
    'message' => 'Image uploaded successfully.',
    'file_path' => 'uploads/' . $newFileName,
    'file_name' => $newFileName
], 201);
?>
*/

// ============================================================================
// FILE 2: /database/schema.sql (UPDATED)
// ============================================================================
/*
Updated USERS table to include:

ALTER TABLE `users` ADD COLUMN `phone_number` VARCHAR(20) DEFAULT NULL;
ALTER TABLE `users` ADD COLUMN `messenger_username` VARCHAR(100) DEFAULT NULL;
ALTER TABLE `users` ADD COLUMN `instagram_username` VARCHAR(100) DEFAULT NULL;

New columns:
- phone_number VARCHAR(20) - For WhatsApp
- messenger_username VARCHAR(100) - For Facebook Messenger
- instagram_username VARCHAR(100) - For Instagram DM
*/

// ============================================================================
// FILE 3: /config/db.php (UPDATED)
// ============================================================================
/*
CHANGES:
1. Auto-migration now creates phone_number, messenger_username, instagram_username columns
2. getUserFullProfile() now retrieves these new fields

Auto-migration code added:
$colsPhoneNumber = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'phone_number'")->fetch();
if (!$colsPhoneNumber) {
    $pdo->exec("ALTER TABLE `users` ADD COLUMN `phone_number` VARCHAR(20) DEFAULT NULL");
}
$colsMessenger = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'messenger_username'")->fetch();
if (!$colsMessenger) {
    $pdo->exec("ALTER TABLE `users` ADD COLUMN `messenger_username` VARCHAR(100) DEFAULT NULL");
}
$colsInstagram = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'instagram_username'")->fetch();
if (!$colsInstagram) {
    $pdo->exec("ALTER TABLE `users` ADD COLUMN `instagram_username` VARCHAR(100) DEFAULT NULL");
}

Updated SELECT in getUserFullProfile():
SELECT id, full_name, email, university, tagline, bio, avatar, phone, 
       phone_number, messenger_username, instagram_username, facebook_url, 
       rating, hours_taught, hours_learned, exchanges_count, created_at 
FROM users 
WHERE id = ?
*/

// ============================================================================
// FILE 4: /api/profile.php (UPDATED)
// ============================================================================
/*
CHANGES:
1. Profile update now accepts phone_number, messenger_username, instagram_username
2. These fields are saved to database
3. Updated profile response includes all new contact fields

Updated POST action=update:

$phoneNumber = isset($data['phone_number']) ? trim($data['phone_number']) : null;
$messengerUsername = isset($data['messenger_username']) ? trim($data['messenger_username']) : null;
$instagramUsername = isset($data['instagram_username']) ? trim($data['instagram_username']) : null;

UPDATE query:
UPDATE users 
SET full_name = ?, 
    tagline = ?, 
    bio = ?, 
    phone = ?, 
    phone_number = ?, 
    messenger_username = ?, 
    instagram_username = ?, 
    facebook_url = ?
WHERE id = ?
*/

// ============================================================================
// FILE 5: /api/skills.php (UPDATED)
// ============================================================================
/*
CHANGES:
1. GET query now includes phone_number, messenger_username, instagram_username
2. POST validation now requires: title, description, AND image
3. Image file path must be provided (from /api/upload_skill_image.php)
4. Dynamically included skills also include contact fields

GET query changes:
SELECT u.full_name AS instructor,
       u.phone_number AS instructorPhoneNumber,
       u.messenger_username AS instructorMessenger,
       u.instagram_username AS instructorInstagram,
       u.facebook_url AS instructorFacebook
FROM skills s
JOIN users u ON s.user_id = u.id

POST validation:
if (empty($title)) {
    jsonError('Skill title is required.');
}
if (empty($description)) {
    jsonError('Skill description is required.');
}
if (empty($image)) {
    jsonError('Image is required for skill upload');
}

Skill creation now uses uploaded image:
INSERT INTO skills (user_id, title, category, mastery_level, description, image, is_featured)
VALUES (?, ?, ?, ?, ?, ?, 0)
// $image is the file_path from upload response

Dynamic user skills also updated to include new contact fields:
'instructorPhoneNumber' => $u['phone_number'],
'instructorMessenger'   => $u['messenger_username'],
'instructorInstagram'   => $u['instagram_username'],
*/

// ============================================================================
// API WORKFLOW - Step by Step
// ============================================================================
/*
SKILL CREATION WORKFLOW:

1. User uploads image via POST /api/upload_skill_image.php
   REQUEST: multipart/form-data with "image" file
   RESPONSE: {
     "success": true,
     "file_path": "uploads/skill_1_1693456789_abc123.jpg",
     "file_name": "skill_1_1693456789_abc123.jpg"
   }

2. User submits skill form via POST /api/skills.php
   REQUEST: {
     "title": "Python Programming",
     "description": "Learn Python basics...",
     "category": "Development",
     "masteryLevel": "Advanced",
     "image": "uploads/skill_1_1693456789_abc123.jpg"  // FROM STEP 1
   }
   RESPONSE: {
     "success": true,
     "message": "Skill published successfully to marketplace.",
     "skill": {...},
     "profile": {...}
   }

PROFILE UPDATE WORKFLOW:

1. User updates profile via POST /api/profile.php?action=update
   REQUEST: {
     "full_name": "John Doe",
     "tagline": "CS Major",
     "bio": "Python expert",
     "phone_number": "+15551234567",
     "messenger_username": "john.doe",
     "instagram_username": "johndoe_official",
     "facebook_url": "https://facebook.com/johndoe"
   }
   RESPONSE: {
     "success": true,
     "message": "Profile updated successfully.",
     "profile": {
       "id": 1,
       "full_name": "John Doe",
       "phone_number": "+15551234567",
       "messenger_username": "john.doe",
       "instagram_username": "johndoe_official",
       "facebook_url": "https://facebook.com/johndoe",
       ...
     }
   }

FETCHING SKILLS WITH CONTACT INFO:

1. GET /api/skills.php
   RESPONSE: {
     "success": true,
     "skills": [
       {
         "id": 1,
         "title": "Python Programming",
         "instructor": "John Doe",
         "instructorPhoneNumber": "+15551234567",
         "instructorMessenger": "john.doe",
         "instructorInstagram": "johndoe_official",
         "instructorFacebook": "https://facebook.com/johndoe",
         ...
       }
     ]
   }
*/

// ============================================================================
// VALIDATION FLOW
// ============================================================================
/*
FRONT-END VALIDATION (JavaScript):
1. Check file type is jpg/jpeg/png
2. Check file size < 5MB
3. Show preview image
4. Validate form fields (title, description not empty)
5. Call upload endpoint
6. Call skill creation endpoint
7. Show error messages for failed operations

BACK-END VALIDATION (PHP):

File Upload Validation (/api/upload_skill_image.php):
- POST request required
- User authentication required
- File must exist
- File extension must be jpg/jpeg/png
- File size must be <= 5MB
- Upload directory must exist and be writable
- File moved to /uploads/ with unique name

Skill Creation Validation (/api/skills.php):
- Title not empty
- Description not empty
- Image file path not empty (from upload response)
- User must be authenticated
*/

// ============================================================================
// CONTACT LINK GENERATION
// ============================================================================
/*
JavaScript Function to Generate Contact URLs:

function getContactUrls(instructor) {
  const urls = {
    whatsapp: null,
    messenger: null,
    instagram: null
  };

  if (instructor.instructorPhoneNumber) {
    urls.whatsapp = `https://wa.me/${instructor.instructorPhoneNumber.replace(/\D/g, '')}`;
  }

  if (instructor.instructorMessenger) {
    urls.messenger = `https://m.me/${instructor.instructorMessenger}`;
  }

  if (instructor.instructorInstagram) {
    urls.instagram = `https://instagram.com/${instructor.instructorInstagram}`;
  }

  return urls;
}

URL FORMATS:

WhatsApp: https://wa.me/<phone_digits_only>
  Example: https://wa.me/15551234567

Messenger: https://m.me/<username>
  Example: https://m.me/john.doe

Instagram: https://instagram.com/<username>
  Example: https://instagram.com/johndoe_official
*/

// ============================================================================
// DATABASE INDEXES (Recommended)
// ============================================================================
/*
ADD INDEXES for better performance:

ALTER TABLE `users` ADD INDEX `idx_phone_number` (`phone_number`);
ALTER TABLE `users` ADD INDEX `idx_messenger_username` (`messenger_username`);
ALTER TABLE `users` ADD INDEX `idx_instagram_username` (`instagram_username`);

ALTER TABLE `skills` ADD INDEX `idx_image` (`image`);
*/

// ============================================================================
// ERROR RESPONSES
// ============================================================================
/*
File Upload Errors:

400 - Image is required for skill upload
400 - Only JPG, JPEG, and PNG files are allowed.
400 - File size must not exceed 5MB.
500 - Failed to save uploaded file.

Skill Creation Errors:

400 - Skill title is required.
400 - Skill description is required.
400 - Image is required for skill upload

Profile Update Errors:

400 - Full name cannot be empty.
401 - Authentication required. Please log in.
*/

?>
