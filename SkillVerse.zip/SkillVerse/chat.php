<?php
/**
 * Skillverse Messenger-style chat widget.
 *
 * Placement:
 * - This file is included by index.php into the main page.
 * - Do not open this file by itself in the browser.
 */
?>
    <!-- Interactive Chat / Messages Drawer -->
    <div class="chat-drawer" id="chatBox">
      <div class="chat-header">
        <div class="chat-user-row" id="chatHeaderMain">
          <button type="button" class="chat-back-btn" id="btnChatBack" title="Back to chats" style="display: none;">←</button>
          <img src="assets/alex_chen.jpg" alt="Chat Partner" class="chat-user-avatar" id="chat-header-avatar" />
          <span class="chat-user-name" id="chat-header-name">Messages</span>
        </div>
        <button type="button" class="modal-close-btn" id="btnChatClose" style="position: static; width: 28px; height: 28px;">✕</button>
      </div>

      <div class="chat-list" id="chatUserList">
        <!-- Students loaded by JavaScript -->
      </div>

      <div class="chat-conversation" id="chatConversation" style="display: none;">
        <div class="chat-messages-container" id="messagesContainer">
          <!-- Live chat bubbles -->
        </div>
        <form class="chat-input-row" id="chat-send-form">
          <input type="text" class="chat-input" id="messageInput" placeholder="Type a message..." autocomplete="off" />
          <button type="submit" class="chat-send-btn" id="btn-chat-send" title="Send">➤</button>
        </form>
      </div>
    </div>
