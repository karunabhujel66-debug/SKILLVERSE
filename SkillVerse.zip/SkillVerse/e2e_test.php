<?php
/**
 * Skillverse Comprehensive Full-Stack Test Suite
 * Tests all API endpoints and database operations through live HTTP requests on Apache
 */

$baseUrl = 'http://localhost/SkillVerse';
$cookieJar = tempnam(sys_get_temp_dir(), 'sk_cookie_');

function testReq($url, $method = 'GET', $data = null) {
    global $cookieJar;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieJar);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieJar);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Accept: application/json']);
        }
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    $json = json_decode($response, true);
    return ['code' => $httpCode, 'data' => $json, 'raw' => $response];
}

$tests = [];
function report($name, $passed, $info = '') {
    global $tests;
    $tests[] = ['name' => $name, 'passed' => $passed, 'info' => $info];
    echo ($passed ? "[PASS] " : "[FAIL] ") . $name . ($info ? " ($info)" : "") . "\n";
}

echo "========================================================\n";
echo "    RUNNING SKILLVERSE FULL-STACK END-TO-END TESTS      \n";
echo "========================================================\n\n";

// 1. Test Static Entrypoint
$r = testReq("$baseUrl/");
report("1. Web Server Root (index.html / index.php)", $r['code'] === 200 && strpos($r['raw'], 'Skillverse') !== false, "HTTP " . $r['code']);

// 2. Test Setup Assistant
$r = testReq("$baseUrl/setup.php");
report("2. Database Setup Page (setup.php)", $r['code'] === 200 && strpos($r['raw'], 'Skillverse Database Installer') !== false, "HTTP " . $r['code']);

// 3. Test Demo / Normal Login
$r = testReq("$baseUrl/api/auth.php?action=login", 'POST', [
    'email' => 'student@university.edu',
    'password' => 'password123'
]);
report("3. User Login (Alex Chen)", $r['code'] === 200 && !empty($r['data']['user']['id']), "User ID: " . ($r['data']['user']['id'] ?? 'none'));

// 4. Test Session Me Check
$r = testReq("$baseUrl/api/auth.php");
report("4. Active Session Verification (api/auth.php)", $r['code'] === 200 && ($r['data']['isLoggedIn'] ?? false) === true, "User: " . ($r['data']['user']['full_name'] ?? ''));

// 5. Test Skills Marketplace Listing
$r = testReq("$baseUrl/api/skills.php");
$skillCount = $r['data']['count'] ?? 0;
report("5. Fetch All Skills Marketplace", $r['code'] === 200 && $skillCount > 0, "Found $skillCount skills");

// 6. Test Category Filter
$r = testReq("$baseUrl/api/skills.php?category=Design");
report("6. Filter Skills by Category (Design)", $r['code'] === 200 && ($r['data']['count'] ?? 0) >= 1, "Found " . ($r['data']['count'] ?? 0) . " Design skills");

// 7. Test Search Query
$r = testReq("$baseUrl/api/skills.php?q=React");
report("7. Search Skills by Keyword (React)", $r['code'] === 200 && ($r['data']['count'] ?? 0) >= 1, "Found " . ($r['data']['count'] ?? 0) . " matches");

// 8. Test Publishing a New Skill
$r = testReq("$baseUrl/api/skills.php", 'POST', [
    'title' => 'Fullstack Next.js Architecture',
    'category' => 'Development',
    'masteryLevel' => 'Expert',
    'description' => 'Hands-on live architectural mentorship for modern SSR web applications.'
]);
$newSkillId = $r['data']['skill']['id'] ?? 0;
report("8. Publish New Skill to MySQL", $r['code'] === 201 && $newSkillId > 0, "Created Skill ID #$newSkillId");

// 9. Test Exchange Requests Listing
$r = testReq("$baseUrl/api/requests.php");
$reqCount = count($r['data']['requests'] ?? []);
report("9. Fetch Incoming Exchange Requests", $r['code'] === 200, "Received $reqCount incoming requests");

// 10. Test Proposing a New Exchange Request
$r = testReq("$baseUrl/api/requests.php", 'POST', [
    'target_skill' => 'Web Design Basics',
    'instructor' => 'Sarah Jenkins',
    'offered_skill' => 'Python Programming',
    'message' => 'Hi Sarah! I would love to trade Python for your web design tutoring.'
]);
$newReqId = $r['data']['request_id'] ?? 0;
report("10. Propose New Exchange Request", $r['code'] === 201 && $newReqId > 0, "Created Request #$newReqId");

// 11. Test Accepting & Scheduling an Exchange Request
$r = testReq("$baseUrl/api/requests.php?action=update_status", 'POST', [
    'id' => 1,
    'status' => 'accepted',
    'scheduled_date' => '2026-08-28 14:00:00',
    'scheduled_platform' => 'Google Meet',
    'scheduled_notes' => 'Discuss Python loops homework'
]);
report("11. Accept & Schedule Exchange Session", $r['code'] === 200 && ($r['data']['success'] ?? false) === true, "Session Confirmed");

// 12. Test Sending a Live Chat Message
$r = testReq("$baseUrl/api/messages.php", 'POST', [
    'partner_name' => 'Sarah Jenkins',
    'message' => 'Hey Sarah! Looking forward to our scheduled session on Friday!'
]);
$msgId = $r['data']['message']['id'] ?? 0;
report("12. Send Real-Time Peer Message", $r['code'] === 201 && $msgId > 0, "Message ID #$msgId");

// 13. Test Fetching Chat Messages Thread
$r = testReq("$baseUrl/api/messages.php?partner_name=" . urlencode('Sarah Jenkins'));
$msgCount = count($r['data']['messages'] ?? []);
report("13. Fetch Chat Conversation Thread", $r['code'] === 200 && $msgCount >= 1, "Thread has $msgCount messages");

// 14. Test Profile Retrieval
$r = testReq("$baseUrl/api/profile.php");
report("14. Fetch User Profile & Impact Stats", $r['code'] === 200 && !empty($r['data']['profile']['skillsTeach']), "Rating: " . ($r['data']['profile']['rating'] ?? '') . " | Exchanges: " . ($r['data']['profile']['exchanges_count'] ?? ''));

// 15. Test Adding a Skill Tag
$r = testReq("$baseUrl/api/profile.php?action=add_tag", 'POST', [
    'skill_name' => 'GraphQL & REST',
    'type' => 'teach'
]);
report("15. Add Skill Tag to Profile (MySQL)", $r['code'] === 200 && in_array('GraphQL & REST ✓', $r['data']['profile']['skillsTeach'] ?? []), "Added 'GraphQL & REST ✓'");

// 16. Test Updating Profile Bio, Tagline, Phone & Facebook Link
$r = testReq("$baseUrl/api/profile.php?action=update", 'POST', [
    'name' => 'Alex Chen',
    'tagline' => 'Computer Science Senior • Fullstack Developer',
    'bio' => 'Passionate about distributed systems, peer education, and algorithms.',
    'phone' => '+1 (555) 234-5678',
    'facebook_url' => 'https://facebook.com/alexchen.tech'
]);
$prof = $r['data']['profile'] ?? [];
report("16. Update Profile Contact Info (Phone & Facebook)", $r['code'] === 200 && ($prof['phone'] ?? '') === '+1 (555) 234-5678' && ($prof['facebook_url'] ?? '') === 'https://facebook.com/alexchen.tech', "Phone: " . ($prof['phone'] ?? 'none') . " | FB: " . ($prof['facebook_url'] ?? 'none'));

// 16b. Test Fetching Another User's Profile (e.g. User 2 Sarah Jenkins)
$r = testReq("$baseUrl/api/profile.php?user_id=2");
report("16b. Fetch Peer User Profile by ID (Sarah Jenkins)", $r['code'] === 200 && ($r['data']['profile']['full_name'] ?? '') === 'Sarah Jenkins', "Fetched: " . ($r['data']['profile']['full_name'] ?? ''));

// 16c. Test Dynamic Browse Real Users & Skills (e.g. Canva or testing)
$r = testReq("$baseUrl/api/skills.php?q=Canva");
$hasCanva = false;
foreach ($r['data']['skills'] ?? [] as $sk) {
    if (stripos($sk['title'], 'Canva') !== false) {
        $hasCanva = true;
        break;
    }
}
report("16c. Dynamic Browse Matches Real MySQL Skills (Canva)", $r['code'] === 200 && $hasCanva, "Found real database Canva listing");

// 17. Test Notifications API
$r = testReq("$baseUrl/api/notifications.php");
$notifCount = count($r['data']['notifications'] ?? []);
report("17. Retrieve Live Notifications", $r['code'] === 200, "Found $notifCount notifications");

// 18. Test Mark Notifications Read
$r = testReq("$baseUrl/api/notifications.php?action=mark_read", 'POST', ['all' => true]);
report("18. Mark All Notifications Read", $r['code'] === 200, "Read receipts synced");

// 19. Test Dashboard Aggregated Summary
$r = testReq("$baseUrl/api/dashboard.php");
report("19. Fetch Dashboard Metrics & Trending", $r['code'] === 200 && count($r['data']['trending'] ?? []) >= 1, "Dashboard loaded with " . count($r['data']['trending'] ?? []) . " trending skills");

// 20. Test Demo User Switch (Switch to Sarah Jenkins)
$r = testReq("$baseUrl/api/auth.php?action=demo_login", 'POST', ['user_id' => 2]);
report("20. Demo Switch Student (Sarah Jenkins)", $r['code'] === 200 && ($r['data']['user']['full_name'] ?? '') === 'Sarah Jenkins', "Switched to: " . ($r['data']['user']['full_name'] ?? ''));

// 21. Test User Registration (New Student Signup)
$testEmail = 'teststudent.' . time() . '@university.edu';
$r = testReq("$baseUrl/api/auth.php?action=signup", 'POST', [
    'full_name' => 'Emma Watson',
    'email' => $testEmail,
    'password' => 'password123',
    'university' => 'Oxford University'
]);
report("21. New Student Registration", $r['code'] === 201 && ($r['data']['user']['email'] ?? '') === $testEmail, "Registered: " . ($r['data']['user']['email'] ?? ''));

// Clean up cookie
@unlink($cookieJar);

echo "\n========================================================\n";
echo "                     TEST SUMMARY                       \n";
echo "========================================================\n";
$passCount = count(array_filter($tests, fn($t) => $t['passed']));
$totalCount = count($tests);
echo "Total Tests: $totalCount | Passed: $passCount | Failed: " . ($totalCount - $passCount) . "\n";
if ($passCount === $totalCount) {
    echo " ALL FULL-STACK FUNCTIONALITIES ARE WORKING PERFECTLY! \n";
}
