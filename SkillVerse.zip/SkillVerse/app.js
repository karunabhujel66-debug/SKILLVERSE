/**
 * Skillverse Application Core
 * Full-Stack Client connecting to PHP REST API & MySQL (XAMPP)
 */

class SkillverseApp {
  constructor() {
    this.currentView = 'dashboard';
    this.currentCategoryFilter = 'All';
    this.currentRequestsTab = 'pending';
    this.searchQuery = '';
    this.currentUser = null;
    this.isLoggedIn = false;
    this.activeChatPartner = '';
    this.activeChatPartnerId = 0;
    this.chatPanel = 'list';

    // Real-time polling handles
    this.chatPollingInterval = null;
    this.notifPollingInterval = null;
    this.lastChatMessageId = 0;

    this.initElements();
    this.bindEvents();
    this.initRouter();
    this.checkAuth();
  }

  /* ==========================================================================
     BACKEND API COMMUNICATION HELPER
     ========================================================================== */
  async api(endpoint, options = {}) {
    const defaultHeaders = {
      'Accept': 'application/json'
    };

    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
      defaultHeaders['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }

    const config = {
      credentials: 'same-origin',
      headers: defaultHeaders,
      ...options
    };

    try {
      const response = await fetch(endpoint, config);
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        if (data.setup_required) {
          this.showToast('Database setup required! Click below or open setup.php.', 'info');
        }
        throw new Error(data.error || `HTTP error ${response.status}`);
      }

      return data;
    } catch (err) {
      console.error(`API Error on [${endpoint}]:`, err.message);
      throw err;
    }
  }

  /* ==========================================================================
     AUTHENTICATION & SESSION
     ========================================================================== */
  async checkAuth() {
    try {
      const res = await this.api('api/auth.php');
      if (res && res.isLoggedIn && res.user) {
        this.isLoggedIn = true;
        this.currentUser = res.user;
        this.renderNavbarUser();
        this.renderAll();
        this.startPolling(); // Begin real-time notification + chat polling
      } else {
        this.isLoggedIn = false;
        this.currentUser = null;
        if (window.location.hash !== '#login') {
          this.navigate('login');
        }
      }
    } catch (e) {
      console.warn('Auth check fallback: Database may need setup.php initialization.');
      // If DB not ready yet, provide a fallback guest view
      if (!this.currentUser) {
        this.navigate('login');
      }
    }
  }

  async login(email, password) {
    try {
      const res = await this.api('api/auth.php?action=login', {
        method: 'POST',
        body: { email, password }
      });
      if (res.success && res.user) {
        this.isLoggedIn = true;
        this.currentUser = res.user;
        this.renderNavbarUser();
        this.showToast(`Welcome back, ${res.user.full_name}!`, 'success');
        this.navigate('dashboard');
        this.renderAll();
        this.startPolling(); // Begin real-time polling on login
      }
    } catch (err) {
      this.showToast(err.message || 'Login failed. Please check credentials.', 'info');
    }
  }

  async signup(fullName, email, password, university) {
    try {
      const res = await this.api('api/auth.php?action=signup', {
        method: 'POST',
        body: { full_name: fullName, email, password, university }
      });
      if (res.success && res.user) {
        this.isLoggedIn = true;
        this.currentUser = res.user;
        this.renderNavbarUser();
        this.showToast(`Account created! Welcome to Skillverse, ${res.user.full_name}.`, 'success');
        this.navigate('dashboard');
        this.renderAll();
        this.startPolling();
      }
    } catch (err) {
      this.showToast(err.message || 'Signup failed.', 'info');
    }
  }

  async demoLogin(userId) {
    try {
      const res = await this.api('api/auth.php?action=demo_login', {
        method: 'POST',
        body: { user_id: userId }
      });
      if (res.success && res.user) {
        this.isLoggedIn = true;
        this.currentUser = res.user;
        this.renderNavbarUser();
        this.userDropdownMenu.classList.remove('open');
        this.showToast(`Switched active student to ${res.user.full_name}!`, 'success');
        this.navigate('dashboard');
        this.renderAll();
        this.startPolling();
      }
    } catch (err) {
      this.showToast('Failed to switch demo account. Is MySQL running?', 'info');
    }
  }

  async logout() {
    this.stopPolling(); // Clear all polling intervals before navigating away
    try {
      await this.api('api/auth.php?action=logout', { method: 'POST' });
    } catch (e) {
      console.warn('Logout API issue:', e);
    }
    this.isLoggedIn = false;
    this.currentUser = null;
    this.userDropdownMenu.classList.remove('open');
    this.showToast('Logged out of Skillverse.', 'info');
    this.navigate('login');
  }

  /* ==========================================================================
     ELEMENT BINDINGS & ROUTING
     ========================================================================== */
  initElements() {
    // Views
    this.views = {
      login: document.getElementById('view-login'),
      dashboard: document.getElementById('view-dashboard'),
      browse: document.getElementById('view-browse'),
      requests: document.getElementById('view-requests'),
      profile: document.getElementById('view-profile')
    };

    // Nav elements
    this.globalNavbar = document.getElementById('global-navbar');
    this.navCenterLinks = document.getElementById('nav-center-links');
    this.navRightActions = document.getElementById('nav-right-actions');
    this.navSearchContainer = document.getElementById('nav-search-container');
    this.navSearchInput = document.getElementById('nav-search-input');
    this.navUserAvatar = document.getElementById('nav-user-avatar');
    this.userDropdownMenu = document.getElementById('user-dropdown-menu');
    this.notificationsPopover = document.getElementById('notifications-popover');
    this.chatDrawer = document.getElementById('chatBox') || document.getElementById('chat-drawer');
    this.notifBadgeCount = document.getElementById('notif-badge-count');
    this.pendingReqsCount = document.getElementById('pending-reqs-count');

    // Modals
    this.modalShareSkill = document.getElementById('modal-share-skill');
    this.modalConnect = document.getElementById('modal-connect');
    this.modalEditProfile = document.getElementById('modal-edit-profile');
    this.modalAddSkill = document.getElementById('modal-add-skill');
    this.modalEditSkill = document.getElementById('modal-edit-skill');
    this.modalEditTag = document.getElementById('modal-edit-tag');
    this.modalSchedule = document.getElementById('modal-schedule');
    this.modalUserProfile = document.getElementById('modal-user-profile');
  }

  bindEvents() {
    // Window scroll navbar effect
    window.addEventListener('scroll', () => {
      if (window.scrollY > 20) {
        this.globalNavbar.classList.add('scrolled');
      } else {
        this.globalNavbar.classList.remove('scrolled');
      }
    });

    // Close popovers when clicking outside
    document.addEventListener('click', (e) => {
      if (!e.target.closest('#btn-toggle-user-dropdown') && !e.target.closest('#user-dropdown-menu')) {
        this.userDropdownMenu.classList.remove('open');
      }
      if (!e.target.closest('#btn-toggle-notifs') && !e.target.closest('#notifications-popover')) {
        this.notificationsPopover.classList.remove('open');
      }
    });

    // Nav Toggle User Dropdown
    document.getElementById('btn-toggle-user-dropdown').addEventListener('click', (e) => {
      e.stopPropagation();
      this.userDropdownMenu.classList.toggle('open');
      this.notificationsPopover.classList.remove('open');
    });

    // Nav Toggle Notifications — delegates to toggleNotificationDropdown()
    document.getElementById('btn-toggle-notifs').addEventListener('click', (e) => {
      e.stopPropagation();
      this.toggleNotificationDropdown();
    });

    // Nav Toggle Chat — always use an arrow function so `this` stays the app
    const chatBtn = document.getElementById('chatBtn') || document.getElementById('btn-toggle-chat');
    if (chatBtn) {
      chatBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.toggleChat();
      });
    }

    const chatCloseBtn = document.getElementById('btnChatClose');
    if (chatCloseBtn) {
      chatCloseBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.closeChat();
      });
    }

    const chatBackBtn = document.getElementById('btnChatBack');
    if (chatBackBtn) {
      chatBackBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.showChatList();
      });
    }

    // Mark all notifications read
    document.getElementById('btn-mark-all-read').addEventListener('click', async () => {
      try {
        await this.api('mark_notification_read.php', { method: 'POST', body: { all: true } });
        this.fetchNotifications();
        this.showToast('All notifications marked as read', 'info');
      } catch (err) {
        console.error(err);
      }
    });

    // Open Share Skill Modal
    document.getElementById('btn-open-share-modal').addEventListener('click', () => {
      this.openModal(this.modalShareSkill);
    });

    // Share Skill Form Submission
    document.getElementById('form-share-skill').addEventListener('submit', async (e) => {
      e.preventDefault();
      const title = document.getElementById('share-skill-title').value.trim();
      const category = document.getElementById('share-skill-category').value;
      const masteryLevel = document.getElementById('share-skill-mastery').value;
      const desc = document.getElementById('share-skill-desc').value.trim();

      if (!title) return;

      try {
        const res = await this.api('api/skills.php', {
          method: 'POST',
          body: {
            title: title,
            category: category,
            masteryLevel: masteryLevel,
            description: desc
          }
        });

        this.closeModals();
        this.showToast(`✨ Skill "${title}" published to MySQL database!`, 'success');
        document.getElementById('form-share-skill').reset();
        this.fetchSkills();
        this.fetchProfile();
      } catch (err) {
        this.showToast(err.message || 'Failed to publish skill.', 'info');
      }
    });

    // Connect / Request Exchange Form Submission
    document.getElementById('form-connect-request').addEventListener('submit', async (e) => {
      e.preventDefault();
      const targetSkill = document.getElementById('connect-target-skill').value;
      const instructor = document.getElementById('connect-target-instructor').value;
      const offeredSkill = document.getElementById('connect-offered-skill').value;
      const message = document.getElementById('connect-message-input').value.trim();

      try {
        const res = await this.api('api/requests.php', {
          method: 'POST',
          body: {
            target_skill: targetSkill,
            instructor: instructor,
            offered_skill: offeredSkill,
            message: message
          }
        });

        this.closeModals();
        this.showToast(res.message || `Request sent to ${instructor}!`, 'success');
        document.getElementById('form-connect-request').reset();
        this.fetchNotifications();
      } catch (err) {
        this.showToast(err.message || 'Failed to send request.', 'info');
      }
    });

    // Edit Profile Modal Open & Save
    document.getElementById('btn-open-edit-profile').addEventListener('click', () => {
      if (this.currentUser) {
        document.getElementById('edit-profile-name').value = this.currentUser.full_name || '';
        document.getElementById('edit-profile-tagline').value = this.currentUser.tagline || '';
        document.getElementById('edit-profile-bio').value = this.currentUser.bio || '';
        const phoneInput = document.getElementById('edit-profile-phone');
        if (phoneInput) phoneInput.value = this.currentUser.phone || '';
        const fbInput = document.getElementById('edit-profile-facebook');
        if (fbInput) fbInput.value = this.currentUser.facebook_url || '';

        // Sync avatar preview to current user photo
        const prevImg = document.getElementById('edit-avatar-preview');
        if (prevImg && this.currentUser.avatar) prevImg.src = this.currentUser.avatar;
      }
      this.openModal(this.modalEditProfile);
    });

    document.getElementById('form-edit-profile').addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('edit-profile-name').value.trim();
      const tagline = document.getElementById('edit-profile-tagline').value.trim();
      const bio = document.getElementById('edit-profile-bio').value.trim();
      const phone = document.getElementById('edit-profile-phone') ? document.getElementById('edit-profile-phone').value.trim() : '';
      const facebook_url = document.getElementById('edit-profile-facebook') ? document.getElementById('edit-profile-facebook').value.trim() : '';

      try {
        const res = await this.api('api/profile.php?action=update', {
          method: 'POST',
          body: { name, tagline, bio, phone, facebook_url }
        });

        if (res.success && res.profile) {
          this.currentUser = res.profile;
        }

        this.closeModals();
        this.renderProfile();
        this.renderNavbarUser();
        this.showToast('Profile updated in MySQL database!', 'success');
      } catch (err) {
        this.showToast(err.message || 'Failed to update profile.', 'info');
      }
    });

    // --- Avatar Upload Wiring ---
    // 1. Hero page: clicking the avatar wrapper opens the hidden file input
    document.getElementById('avatar-upload-wrapper').addEventListener('click', () => {
      document.getElementById('avatar-file-input').click();
    });
    document.getElementById('avatar-file-input').addEventListener('change', (e) => {
      if (e.target.files[0]) this.uploadAvatar(e.target.files[0]);
    });

    // 2. Modal: "Choose Photo" button opens the modal's hidden file input
    document.getElementById('btn-trigger-avatar-upload').addEventListener('click', () => {
      document.getElementById('modal-avatar-file-input').click();
    });
    document.getElementById('modal-avatar-file-input').addEventListener('change', (e) => {
      if (e.target.files[0]) this.uploadAvatar(e.target.files[0], true);
    });

    // Add Skill Modal Form (Teach or Learn)
    document.getElementById('form-add-skill').addEventListener('submit', async (e) => {
      e.preventDefault();
      const skillName = document.getElementById('add-skill-input').value.trim();
      const type = document.getElementById('add-skill-type').value;

      if (!skillName) return;

      try {
        const res = await this.api('api/profile.php?action=add_tag', {
          method: 'POST',
          body: { skill_name: skillName, type: type }
        });

        if (res.success && res.profile) {
          this.currentUser = res.profile;
        }

        this.closeModals();
        this.renderProfile();
        this.showToast(`Added "${skillName}" to your profile!`, 'success');
        document.getElementById('form-add-skill').reset();
      } catch (err) {
        this.showToast(err.message || 'Failed to add skill.', 'info');
      }
    });

    // Schedule Session Form
    document.getElementById('form-schedule').addEventListener('submit', async (e) => {
      e.preventDefault();
      const reqId = document.getElementById('schedule-req-id').value;
      const dateVal = document.getElementById('schedule-date').value;
      const platform = document.getElementById('schedule-platform').value;
      const notes = document.getElementById('schedule-notes').value.trim();

      try {
        const res = await this.api('api/requests.php?action=update_status', {
          method: 'POST',
          body: {
            id: reqId,
            status: 'accepted',
            scheduled_date: dateVal,
            scheduled_platform: platform,
            scheduled_notes: notes
          }
        });

        this.closeModals();
        this.showToast(res.message || 'Session confirmed & saved to database!', 'success');
        this.fetchRequests();
        this.fetchProfile();
        this.fetchDashboard();
      } catch (err) {
        this.showToast(err.message || 'Failed to schedule session.', 'info');
      }
    });

    // Chat Send Form — AJAX, no page reload
    const chatForm = document.getElementById('chat-send-form');
    if (chatForm) {
      chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.sendChatMessage();
      });
    }

    // Auth Switcher Buttons (Log In / Sign Up)
    document.getElementById('btn-auth-mode-login').addEventListener('click', () => {
      this.setAuthMode('login');
    });

    document.getElementById('btn-auth-mode-signup').addEventListener('click', () => {
      this.setAuthMode('signup');
    });

    // Auth Form Submission
    document.getElementById('auth-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const isSignup = document.getElementById('btn-auth-mode-signup').classList.contains('active');
      const email = document.getElementById('auth-input-email').value.trim();
      const password = document.getElementById('auth-input-password').value.trim();
      const fullName = document.getElementById('auth-input-name').value.trim();
      const uni = document.getElementById('auth-input-uni').value.trim();

      if (isSignup) {
        this.signup(fullName, email, password, uni);
      } else {
        this.login(email, password);
      }
    });

    // Logout Button
    document.getElementById('btn-logout').addEventListener('click', () => {
      this.logout();
    });

    // Dashboard Search Input -> Instant Navigation to Browse
    const dashSearch = document.getElementById('dashboard-search-input');
    dashSearch.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        this.searchQuery = dashSearch.value.trim();
        this.navigate('browse');
        if (this.navSearchInput) this.navSearchInput.value = this.searchQuery;
        this.fetchSkills();
      }
    });

    dashSearch.addEventListener('input', (e) => {
      this.searchQuery = e.target.value.trim();
    });

    // Browse In-Navbar Search Input
    this.navSearchInput.addEventListener('input', (e) => {
      this.searchQuery = e.target.value.trim();
      this.fetchSkills();
    });

    // Category Filter Pills on Browse Page
    const catContainer = document.getElementById('category-filter-list');
    catContainer.addEventListener('click', (e) => {
      const btn = e.target.closest('.category-pill');
      if (!btn) return;
      catContainer.querySelectorAll('.category-pill').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      this.currentCategoryFilter = btn.dataset.category;
      this.fetchSkills();
    });

    // Live DB filter toggle toast
    document.getElementById('btn-toggle-filters-menu').addEventListener('click', () => {
      this.showToast(`Filtering active database records for category "${this.currentCategoryFilter}".`, 'info');
    });

    // Requests Filter Tabs
    const reqTabContainer = document.getElementById('requests-tab-filter');
    reqTabContainer.addEventListener('click', (e) => {
      const btn = e.target.closest('.req-filter-pill');
      if (!btn) return;
      reqTabContainer.querySelectorAll('.req-filter-pill').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      this.currentRequestsTab = btn.dataset.tab;
      this.fetchRequests();
    });

    // Forgot password link
    document.getElementById('link-forgot-password').addEventListener('click', () => {
      this.showToast('For testing, default password for all seed accounts is "password123".', 'info');
    });
  }

  /* ==========================================================================
     VIEW ROUTING
     ========================================================================== */
  initRouter() {
    const handleHash = () => {
      const hash = window.location.hash.replace('#', '') || 'dashboard';
      if (['login', 'dashboard', 'browse', 'requests', 'profile'].includes(hash)) {
        this.navigate(hash, false);
      } else {
        this.navigate('dashboard', false);
      }
    };

    window.addEventListener('hashchange', handleHash);
    handleHash();
  }

  navigate(viewName, updateHash = true) {
    if (!this.isLoggedIn && viewName !== 'login') {
      viewName = 'login';
    }

    this.currentView = viewName;

    // Switch active view container
    Object.keys(this.views).forEach(key => {
      if (this.views[key]) {
        if (key === viewName) {
          this.views[key].classList.add('active');
        } else {
          this.views[key].classList.remove('active');
        }
      }
    });

    // Update Navigation links active indicator
    const links = document.querySelectorAll('.nav-link');
    links.forEach(l => {
      if (l.dataset.view === viewName || (viewName === 'dashboard' && l.dataset.view === 'dashboard')) {
        l.classList.add('active');
      } else {
        l.classList.remove('active');
      }
    });

    // Handle Navbar visibility on Login screen
    if (viewName === 'login') {
      this.navCenterLinks.style.display = 'none';
      this.navRightActions.style.display = 'none';
      this.navSearchContainer.classList.remove('visible');
    } else {
      this.navCenterLinks.style.display = 'flex';
      this.navRightActions.style.display = 'flex';

      if (viewName === 'browse') {
        this.navSearchContainer.classList.add('visible');
      } else {
        this.navSearchContainer.classList.remove('visible');
      }
    }

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (updateHash) {
      window.location.hash = viewName;
    }

    // Trigger data fetch for active view
    if (viewName === 'browse') this.fetchSkills();
    if (viewName === 'requests') this.fetchRequests();
    if (viewName === 'profile') this.fetchProfile();
    if (viewName === 'dashboard') this.fetchDashboard();
  }

  /* ==========================================================================
     AUTH MODE SWITCHER
     ========================================================================== */
  setAuthMode(mode) {
    const btnLogin = document.getElementById('btn-auth-mode-login');
    const btnSignup = document.getElementById('btn-auth-mode-signup');
    const title = document.getElementById('auth-main-title');
    const subtitle = document.getElementById('auth-main-subtitle');
    const nameGroup = document.getElementById('group-signup-name');
    const uniGroup = document.getElementById('group-signup-uni');
    const submitText = document.getElementById('btn-auth-text');

    if (mode === 'signup') {
      btnLogin.classList.remove('active');
      btnSignup.classList.add('active');
      title.textContent = 'Create Account';
      subtitle.textContent = 'Join Skillverse to start exchanging knowledge.';
      nameGroup.style.display = 'block';
      uniGroup.style.display = 'block';
      submitText.textContent = 'Sign Up';
    } else {
      btnSignup.classList.remove('active');
      btnLogin.classList.add('active');
      title.textContent = 'Welcome Back';
      subtitle.textContent = 'Log in to continue sharing skills.';
      nameGroup.style.display = 'none';
      uniGroup.style.display = 'none';
      submitText.textContent = 'Log In';
    }
  }

  /* ==========================================================================
     RENDERERS & API DATA SYNC
     ========================================================================== */
  renderAll() {
    this.renderNavbarUser();
    this.fetchNotifications();
    this.fetchDashboard();
    this.fetchSkills();
    this.fetchRequests();
    this.fetchProfile();
  }

  renderNavbarUser() {
    if (!this.currentUser) return;
    const u = this.currentUser;
    const nameEl = document.getElementById('dropdown-user-name');
    const emailEl = document.getElementById('dropdown-user-email');
    const navAvatar = document.getElementById('nav-user-avatar');

    if (nameEl) nameEl.textContent = u.full_name || u.name;
    if (emailEl) emailEl.textContent = u.email;
    if (navAvatar && u.avatar) navAvatar.src = u.avatar;
  }

  async fetchNotifications() {
    if (!this.isLoggedIn) return;
    try {
      const res = await this.api('get_notifications.php');
      if (res && res.notifications) {
        this.renderNotifications(res.notifications, res.unreadCount);
      }
    } catch (err) {
      console.warn('Notifications fetch error:', err);
    }
  }

  renderNotifications(notifications, unreadCount) {
    const list = document.getElementById('notif-items-list');
    if (!list) return;

    list.innerHTML = '';
    if (this.notifBadgeCount) {
      this.notifBadgeCount.textContent = unreadCount;
      this.notifBadgeCount.style.display = unreadCount > 0 ? 'inline-block' : 'none';
    }
    const chatBadge = document.getElementById('chat-badge-count');
    if (chatBadge) {
      chatBadge.textContent = unreadCount;
      chatBadge.style.display = unreadCount > 0 ? 'inline-block' : 'none';
    }

    if (!notifications || notifications.length === 0) {
      list.innerHTML = '<div style="padding: 1.5rem; text-align: center; color: var(--text-muted); font-size: 0.86rem;">No new notifications</div>';
      return;
    }

    notifications.forEach(n => {
      const item = document.createElement('div');
      item.className = `notif-item ${n.unread ? 'unread' : ''}`;
      item.innerHTML = `
        <span class="notif-icon">${n.icon || '🔔'}</span>
        <div>
          <div class="notif-text">${n.text}</div>
          <div class="notif-time">${n.time}</div>
        </div>
      `;
      item.addEventListener('click', async () => {
        try {
          await this.api('mark_notification_read.php', { method: 'POST', body: { id: n.id } });
          this.fetchNotifications();
        } catch (e) { }
      });
      list.appendChild(item);
    });
  }

  async fetchDashboard() {
    if (!this.isLoggedIn) return;
    try {
      const res = await this.api('api/dashboard.php');
      if (res) {
        if (res.user) {
          this.currentUser = res.user;
          this.renderNavbarUser();
        }

        const greeting = document.getElementById('dashboard-welcome-heading');
        if (greeting && this.currentUser) {
          const firstName = (this.currentUser.full_name || this.currentUser.name || 'Student').split(' ')[0];
          greeting.textContent = `Welcome back, ${firstName}`;
        }

        // Quick Stats Update
        const statPending = document.getElementById('dash-stat-pending');
        const statSkills = document.getElementById('dash-stat-skills');
        const statExchanges = document.getElementById('dash-stat-exchanges');

        if (statPending) statPending.textContent = res.pendingRequestsCount ?? 0;
        if (statExchanges) statExchanges.textContent = this.currentUser?.exchanges_count ?? 0;

        // Render Trending Skills from DB
        this.renderDashboardTrending(res.trending || []);
      }
    } catch (err) {
      console.warn('Dashboard fetch error:', err);
    }
  }

  renderDashboardTrending(trendingSkills) {
    const grid = document.getElementById('dashboard-trending-grid');
    if (!grid) return;

    if (trendingSkills.length === 0) {
      grid.innerHTML = '<p style="color: var(--text-muted);">No trending skills available yet.</p>';
      return;
    }

    grid.innerHTML = '';
    const icons = {
      'Development': '&lt;&gt;',
      'Design': '🎨',
      'Language': '文A',
      'Business': '📊',
      'Photography': '📷',
      'Music & Audio': '🎵'
    };

    trendingSkills.forEach(item => {
      const card = document.createElement('div');
      card.className = 'trending-card';
      const icon = icons[item.category] || '💡';

      card.innerHTML = `
        <div class="trending-card-top">
          <div class="trending-icon-circle">${icon}</div>
          <div class="trending-meta">
            <h3 class="trending-title">${item.title}</h3>
            <span class="tag-badge">${item.category}</span>
          </div>
        </div>
        <p class="trending-desc">${item.description}</p>
        <button class="btn-connect-mint" onclick="app.openConnectModal('${item.title.replace(/'/g, "\\'")}', '${item.category}', '${item.instructor.replace(/'/g, "\\'")}')">Connect</button>
      `;
      grid.appendChild(card);
    });
  }

  async fetchSkills() {
    try {
      const params = new URLSearchParams();
      if (this.currentCategoryFilter && this.currentCategoryFilter !== 'All') {
        params.append('category', this.currentCategoryFilter);
      }
      if (this.searchQuery) {
        params.append('q', this.searchQuery);
      }

      const res = await this.api(`api/skills.php?${params.toString()}`);
      if (res && res.skills) {
        this.renderBrowseSkills(res.skills);
        const statSkills = document.getElementById('dash-stat-skills');
        if (statSkills) statSkills.textContent = res.skills.length;
      }
    } catch (err) {
      console.warn('Skills fetch error:', err);
    }
  }

  renderBrowseSkills(skills) {
    const grid = document.getElementById('browse-skills-grid');
    if (!grid) return;

    grid.innerHTML = '';

    if (!skills || skills.length === 0) {
      grid.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🔍</div>
          <h3 class="empty-state-title">No skills match your criteria</h3>
          <p class="empty-state-desc">Try changing your search term or select "All" categories to discover more.</p>
        </div>
      `;
      return;
    }

    skills.forEach(skill => {
      const card = document.createElement('div');
      const isMine = this.currentUser && (Number(skill.user_id) === Number(this.currentUser.id) || skill.instructor === this.currentUser.full_name);

      const connectBtnHtml = isMine
        ? `<span class="my-skill-badge" style="font-size: 0.78rem; font-weight: 700; color: var(--brand-dark-green); padding: 0.4rem 0.8rem; background: var(--brand-mint-light); border-radius: 9999px; cursor: pointer;" title="Click to view full profile">Your Skill Listing</span>`
        : `<button class="btn-card-connect ${skill.isFeatured ? 'dark' : ''}" onclick="event.stopPropagation(); app.openConnectModal('${(skill.title || '').replace(/'/g, "\\'")}', '${(skill.category || '').replace(/'/g, "\\'")}', '${(skill.instructor || '').replace(/'/g, "\\'")}')">Connect</button>`;

      if (skill.isFeatured) {
        card.className = 'skill-card featured-split';
        card.innerHTML = `
          <div class="skill-card-img-wrap" title="View ${skill.instructor}'s profile">
            <span class="skill-card-tag">${skill.category}</span>
            <img src="${skill.image}" alt="${skill.title}" class="skill-card-img" />
          </div>
          <div class="skill-card-body">
            <div>
              <h3 class="skill-card-title">${skill.title}</h3>
              <p class="skill-card-desc">${skill.description}</p>
              
              <div class="skill-mastery-box">
                <div class="mastery-header">
                  <span>Mastery Level</span>
                  <span class="mastery-label">${skill.masteryLevel || 'Advanced'}</span>
                </div>
                <div class="mastery-bar-bg">
                  <div class="mastery-bar-fill" style="width: 85%;"></div>
                </div>
              </div>
            </div>

            <div class="skill-card-footer">
              <div class="instructor-info" title="View ${skill.instructor}'s profile">
                <img src="${skill.avatar || 'assets/alex_chen.jpg'}" alt="${skill.instructor}" class="instructor-avatar" />
                <span class="instructor-name">${skill.instructor}</span>
              </div>
              ${connectBtnHtml}
            </div>
          </div>
        `;
      } else {
        card.className = 'skill-card';
        card.innerHTML = `
          <div class="skill-card-img-wrap" title="View ${skill.instructor}'s profile">
            <span class="skill-card-tag">${skill.category}</span>
            <img src="${skill.image}" alt="${skill.title}" class="skill-card-img" />
          </div>
          <div class="skill-card-body">
            <div>
              <h3 class="skill-card-title">${skill.title}</h3>
              <p class="skill-card-desc">${skill.description}</p>
            </div>

            <div class="skill-card-footer">
              <div class="instructor-info" title="View ${skill.instructor}'s profile">
                <img src="${skill.avatar || 'assets/alex_chen.jpg'}" alt="${skill.instructor}" class="instructor-avatar" />
                <span class="instructor-name">${skill.instructor}</span>
              </div>
              ${connectBtnHtml}
            </div>
          </div>
        `;
      }

      // Single-clicking anywhere on the skill card (including 'Your Skill Listing') opens the full profile view
      card.addEventListener('click', (e) => {
        if (e.target.closest('.btn-card-connect')) {
          return;
        }
        this.openUserProfileModal(skill);
      });

      grid.appendChild(card);
    });
  }

  async fetchRequests() {
    if (!this.isLoggedIn) return;
    try {
      const res = await this.api(`api/requests.php?tab=${this.currentRequestsTab}`);
      if (res) {
        if (res.counts) {
          const tabAll = document.getElementById('count-tab-all');
          const tabPending = document.getElementById('pending-reqs-count');
          const tabAccepted = document.getElementById('count-tab-accepted');
          const tabDeclined = document.getElementById('count-tab-declined');

          if (tabAll) tabAll.textContent = res.counts.total;
          if (tabPending) tabPending.textContent = res.counts.pending;
          if (tabAccepted) tabAccepted.textContent = res.counts.accepted;
          if (tabDeclined) tabDeclined.textContent = res.counts.declined;
        }

        this.renderRequests(res.requests || []);
      }
    } catch (err) {
      console.warn('Requests fetch error:', err);
    }
  }

  renderRequests(list) {
    const grid = document.getElementById('requests-cards-grid');
    if (!grid) return;

    grid.innerHTML = '';

    if (!list || list.length === 0) {
      grid.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📭</div>
          <h3 class="empty-state-title">No ${this.currentRequestsTab} requests</h3>
          <p class="empty-state-desc">You're all caught up! Browse new skills or share another topic you can teach to receive requests.</p>
        </div>
      `;
      return;
    }

    list.forEach(req => {
      const card = document.createElement('div');
      card.className = 'request-card';

      let actionsHtml = '';
      if (req.status === 'pending') {
        actionsHtml = `
          <div class="request-actions-row">
            <button class="btn-req-accept" onclick="app.openScheduleModal('${req.id}', '${req.name.replace(/'/g, "\\'")}', '${req.skill.replace(/'/g, "\\'")}')">Accept</button>
            <button class="btn-req-decline" onclick="app.declineRequest('${req.id}', '${req.name.replace(/'/g, "\\'")}')">Decline</button>
          </div>
        `;
      } else if (req.status === 'accepted') {
        actionsHtml = `
          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: auto; padding-top: 0.8rem;">
            <span class="request-status-pill accepted">✓ Accepted</span>
            <button class="btn-req-accept" style="padding: 0.4rem 1rem; font-size: 0.82rem;" onclick="app.openChatWith(${Number(req.sender_id) || 0}, '${req.name.replace(/'/g, "\\'")}')">Message 💬</button>
          </div>
        `;
      } else if (req.status === 'declined') {
        actionsHtml = `
          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: auto; padding-top: 0.8rem;">
            <span class="request-status-pill declined">✕ Declined</span>
            <button class="btn-req-decline" style="padding: 0.4rem 0.8rem; font-size: 0.82rem;" onclick="app.undoDecline('${req.id}', '${req.name.replace(/'/g, "\\'")}')">Undo</button>
          </div>
        `;
      }

      card.innerHTML = `
        <div>
          <div class="request-user-row">
            <div class="request-user-meta">
              <img src="${req.avatar || 'assets/alex_chen.jpg'}" alt="${req.name}" class="request-avatar" />
              <div class="request-user-details">
                <span class="request-user-name">${req.name}</span>
                <span class="request-user-school">${req.school}</span>
              </div>
            </div>
            <span class="request-time-pill">${req.time}</span>
          </div>

          <div class="request-skill-section">
            <div class="request-skill-label">REQUESTED SKILL</div>
            <span class="request-skill-tag">${req.skill}</span>
          </div>

          <div class="request-message-quote">"${req.message}"</div>
        </div>

        ${actionsHtml}
      `;

      grid.appendChild(card);
    });
  }

  async declineRequest(reqId, name) {
    try {
      await this.api('api/requests.php?action=update_status', {
        method: 'POST',
        body: { id: reqId, status: 'declined' }
      });
      this.showToast(`Declined request from ${name}.`, 'info');
      this.fetchRequests();
    } catch (err) {
      this.showToast('Failed to decline request.', 'info');
    }
  }

  async undoDecline(reqId, name) {
    try {
      await this.api('api/requests.php?action=update_status', {
        method: 'POST',
        body: { id: reqId, status: 'pending' }
      });
      this.showToast(`Request from ${name} restored to Pending!`, 'success');
      this.fetchRequests();
    } catch (err) {
      this.showToast('Failed to restore request.', 'info');
    }
  }

  async fetchProfile() {
    if (!this.isLoggedIn) return;
    try {
      const res = await this.api('api/profile.php');
      if (res && res.profile) {
        this.currentUser = res.profile;
        this.renderProfile();
      }
    } catch (err) {
      console.warn('Profile fetch error:', err);
    }
  }

  /**
   * Upload a new profile picture.
   * @param {File}    file        The image File object from a file input.
   * @param {boolean} isFromModal If true, show uploading state on the modal preview too.
   */
  async uploadAvatar(file, isFromModal = false) {
    // Client-side size guard (5 MB)
    if (file.size > 5 * 1024 * 1024) {
      this.showToast('Image is too large. Please choose a file under 5 MB.', 'info');
      return;
    }

    // Optimistic local preview using an object URL
    const localUrl = URL.createObjectURL(file);
    const heroAvatar = document.getElementById('profile-hero-avatar');
    const navAvatar = document.getElementById('nav-user-avatar');
    const modalPreview = document.getElementById('edit-avatar-preview');
    const uploadBtn = document.getElementById('btn-trigger-avatar-upload');

    if (heroAvatar) heroAvatar.src = localUrl;
    if (navAvatar) navAvatar.src = localUrl;
    if (modalPreview) { modalPreview.src = localUrl; modalPreview.classList.add('uploading'); }
    if (uploadBtn) { uploadBtn.disabled = true; uploadBtn.textContent = '\u23f3 Uploading\u2026'; }

    try {
      const formData = new FormData();
      formData.append('avatar', file);

      // Pass FormData directly — api() detects it and skips JSON.stringify
      const res = await this.api('api/profile.php?action=upload_avatar', {
        method: 'POST',
        body: formData
      });

      if (res.success && res.profile) {
        this.currentUser = res.profile;
        this.renderProfile();
        this.renderNavbarUser();
      }

      this.showToast('\u2705 Profile picture updated!', 'success');
    } catch (err) {
      // Revert previews on failure
      const fallback = this.currentUser?.avatar || 'assets/alex_chen.jpg';
      if (heroAvatar) heroAvatar.src = fallback;
      if (navAvatar) navAvatar.src = fallback;
      if (modalPreview) modalPreview.src = fallback;
      this.showToast(err.message || 'Failed to upload image. Please try again.', 'info');
    } finally {
      URL.revokeObjectURL(localUrl);
      if (modalPreview) modalPreview.classList.remove('uploading');
      if (uploadBtn) { uploadBtn.disabled = false; uploadBtn.textContent = '\ud83d\udcf7 Choose Photo'; }
      // Reset both file inputs so the same file can be re-selected
      const fi1 = document.getElementById('avatar-file-input');
      const fi2 = document.getElementById('modal-avatar-file-input');
      if (fi1) fi1.value = '';
      if (fi2) fi2.value = '';
    }
  }

  renderProfile() {
    if (!this.currentUser) return;
    const u = this.currentUser;

    const nameEl = document.getElementById('profile-user-name');
    const taglineEl = document.getElementById('profile-tagline');
    const bioEl = document.getElementById('profile-bio');

    const heroAvatar = document.getElementById('profile-hero-avatar');

    if (nameEl) nameEl.textContent = u.full_name || u.name;
    if (taglineEl) taglineEl.textContent = u.tagline;
    if (bioEl) bioEl.textContent = u.bio;

    if (heroAvatar && u.avatar) heroAvatar.src = u.avatar;

    // Render Contact Info Action Buttons
    const btnPhone = document.getElementById('profile-btn-phone');
    const txtPhone = document.getElementById('profile-phone-text');
    const btnFb = document.getElementById('profile-btn-facebook');
    const txtFb = document.getElementById('profile-facebook-text');
    const contactRow = document.getElementById('profile-contact-actions');

    if (contactRow) {
      let hasAnyContact = false;
      if (u.phone && u.phone.trim()) {
        btnPhone.style.display = 'inline-flex';
        btnPhone.href = `tel:${u.phone.replace(/[^0-9+]/g, '') || u.phone}`;
        if (txtPhone) txtPhone.textContent = u.phone;
        hasAnyContact = true;
      } else {
        btnPhone.style.display = 'none';
      }

      if (u.facebook_url && u.facebook_url.trim()) {
        btnFb.style.display = 'inline-flex';
        const fbUrl = u.facebook_url.startsWith('http') ? u.facebook_url : `https://${u.facebook_url}`;
        btnFb.href = fbUrl;
        if (txtFb) txtFb.textContent = 'Facebook Profile';
        hasAnyContact = true;
      } else {
        btnFb.style.display = 'none';
      }

      contactRow.style.display = hasAnyContact ? 'flex' : 'none';
    }

    // Render Skills I Teach
    const teachWrap = document.getElementById('profile-teach-tags-wrap');
    if (teachWrap) {
      teachWrap.innerHTML = '';
      (u.skillsTeach || []).forEach((skill) => {
        const tag = document.createElement('span');
        tag.className = 'tag-teach';
        tag.textContent = skill;
        tag.title = 'Click to remove tag from database';
        tag.addEventListener('click', async () => {
          try {
            await this.api('api/profile.php?action=delete_tag', {
              method: 'POST',
              body: { skill_name: skill, type: 'teach' }
            });
            this.fetchProfile();
          } catch (e) { }
        });
        teachWrap.appendChild(tag);
      });
      const addBtn = document.createElement('button');
      addBtn.className = 'btn-add-skill-tag';
      addBtn.textContent = '+ Add Skill';
      addBtn.onclick = () => this.openAddSkillModal('teach');
      teachWrap.appendChild(addBtn);
    }

    // Render Skills I Want to Learn
    const learnWrap = document.getElementById('profile-learn-tags-wrap');
    if (learnWrap) {
      learnWrap.innerHTML = '';
      (u.skillsLearn || []).forEach((skill) => {
        const tag = document.createElement('span');
        tag.className = 'tag-learn';
        tag.textContent = skill;
        tag.title = 'Click to remove tag from database';
        tag.addEventListener('click', async () => {
          try {
            await this.api('api/profile.php?action=delete_tag', {
              method: 'POST',
              body: { skill_name: skill, type: 'learn' }
            });
            this.fetchProfile();
          } catch (e) { }
        });
        learnWrap.appendChild(tag);
      });
      const addBtn = document.createElement('button');
      addBtn.className = 'btn-add-skill-tag';
      addBtn.textContent = '+ Add Skill';
      addBtn.onclick = () => this.openAddSkillModal('learn');
      learnWrap.appendChild(addBtn);
    }

    // Render Recent Exchanges
    const exchangesGrid = document.getElementById('recent-exchanges-grid');
    if (exchangesGrid && u.recentExchanges) {
      exchangesGrid.innerHTML = '';
      u.recentExchanges.forEach(ex => {
        const card = document.createElement('div');
        card.className = 'exchange-card';
        const badgeClass = ex.type === 'taught' ? 'exchange-badge-taught' : 'exchange-badge-learned';
        const badgeLabel = ex.type === 'taught' ? 'Taught' : 'Learned';

        card.innerHTML = `
          <div class="exchange-card-top">
            <span class="${badgeClass}">${badgeLabel}</span>
            <span class="exchange-date">${ex.time}</span>
          </div>
          <div class="exchange-topic">${ex.topic}</div>
          <div class="exchange-partner">
            <img src="${ex.partner_avatar || 'assets/alex_chen.jpg'}" alt="${ex.partner_name}" class="exchange-partner-avatar" />
            <span>with ${ex.partner_name}</span>
          </div>
        `;
        exchangesGrid.appendChild(card);
      });
    }
  }

  /* ==========================================================================
     REAL-TIME POLLING LIFECYCLE
     ========================================================================== */

  /**
   * Start all background polling loops.
   * Called once after successful login / auth check.
   */
  startPolling() {
    if (!this.notifPollingInterval) {
      this.notifPollingInterval = setInterval(() => {
        if (this.isLoggedIn) {
          this.loadNotifications();
        }
      }, 3000);
    }
  }

  /**
   * Stop all background polling loops.
   * Called on logout to prevent background requests after session ends.
   */
  stopPolling() {
    if (this.notifPollingInterval) {
      clearInterval(this.notifPollingInterval);
      this.notifPollingInterval = null;
    }
    this.stopChatPolling();
  }

  /** Start the 3-second chat message polling loop. */
  startChatPolling() {
    if (!this.chatPollingInterval) {
      this.chatPollingInterval = setInterval(() => {
        const drawer = document.getElementById('chatBox') || document.getElementById('chat-drawer');
        if (drawer && drawer.classList.contains('open') && this.isLoggedIn && this.chatPanel === 'conversation') {
          this.pollChatMessages();
        }
      }, 3000);
    }
  }

  /** Stop the chat polling loop (called when drawer closes). */
  stopChatPolling() {
    if (this.chatPollingInterval) {
      clearInterval(this.chatPollingInterval);
      this.chatPollingInterval = null;
    }
  }

  /* ==========================================================================
     NOTIFICATION HELPERS
     ========================================================================== */

  /**
   * Public wrapper for fetchNotifications().
   * Satisfies the loadNotifications() naming convention.
   */
  async loadNotifications() {
    return this.fetchNotifications();
  }

  /**
   * Toggle the notifications popover open/closed.
   * Fetches fresh data whenever it is opened.
   */
  toggleNotificationDropdown() {
    this.notificationsPopover.classList.toggle('open');
    this.userDropdownMenu.classList.remove('open');
    if (this.notificationsPopover.classList.contains('open')) {
      this.loadNotifications();
    }
  }

  /* ==========================================================================
     CHAT HELPERS
     ========================================================================== */

  /**
   * Toggle the chat box open/closed.
   * Do not pass this.toggleChat as a raw addEventListener callback
   * (that would lose `this`). Always wrap: () => this.toggleChat()
   */
  toggleChat(partnerName) {
    const drawer = document.getElementById('chatBox') || document.getElementById('chat-drawer');
    if (!drawer) return;

    const isOpen = drawer.classList.contains('open');

    if (isOpen && !partnerName) {
      this.closeChat();
      return;
    }

    drawer.classList.add('open');

    if (partnerName) {
      this.openChatWith(0, partnerName);
      return;
    }

    this.showChatList();
    this.startChatPolling();
  }

  closeChat() {
    const drawer = document.getElementById('chatBox') || document.getElementById('chat-drawer');
    if (drawer) drawer.classList.remove('open');
    this.stopChatPolling();
  }

  showChatList() {
    this.chatPanel = 'list';
    this.activeChatPartnerId = 0;
    const list = document.getElementById('chatUserList');
    const convo = document.getElementById('chatConversation');
    const backBtn = document.getElementById('btnChatBack');
    const nameEl = document.getElementById('chat-header-name');
    const avatarEl = document.getElementById('chat-header-avatar');
    if (list) list.style.display = 'block';
    if (convo) convo.style.display = 'none';
    if (backBtn) backBtn.style.display = 'none';
    if (nameEl) nameEl.textContent = 'Messages';
    if (avatarEl) avatarEl.src = 'assets/alex_chen.jpg';
    this.loadChatUsers();
  }

  openChatWith(userId, partnerName, avatar) {
    const drawer = document.getElementById('chatBox') || document.getElementById('chat-drawer');
    if (!drawer) return;
    drawer.classList.add('open');

    this.chatPanel = 'conversation';
    this.activeChatPartnerId = Number(userId) || 0;
    this.activeChatPartner = partnerName || '';
    this.lastChatMessageId = 0;

    const list = document.getElementById('chatUserList');
    const convo = document.getElementById('chatConversation');
    const backBtn = document.getElementById('btnChatBack');
    const nameEl = document.getElementById('chat-header-name');
    const avatarEl = document.getElementById('chat-header-avatar');
    if (list) list.style.display = 'none';
    if (convo) convo.style.display = 'flex';
    if (backBtn) backBtn.style.display = 'inline-flex';
    if (nameEl) nameEl.textContent = partnerName || 'Student';
    if (avatarEl && avatar) avatarEl.src = avatar;

    this.loadMessages();
    this.startChatPolling();
  }

  async loadChatUsers() {
    const list = document.getElementById('chatUserList');
    if (!list) return;
    try {
      const res = await this.api('get_messages.php?users=1');
      list.innerHTML = '';
      if (!res.users || res.users.length === 0) {
        list.innerHTML = '<div style="padding:1.2rem;text-align:center;color:var(--text-muted);font-size:0.85rem;">No other students yet.</div>';
        return;
      }
      res.users.forEach((u) => {
        const item = document.createElement('div');
        item.className = 'chat-list-item';

        const img = document.createElement('img');
        img.src = u.avatar || 'assets/alex_chen.jpg';
        img.alt = '';

        const info = document.createElement('div');
        const name = document.createElement('div');
        name.className = 'chat-list-item-name';
        name.textContent = u.full_name;
        const meta = document.createElement('div');
        meta.className = 'chat-list-item-meta';
        meta.textContent = u.university || 'Student';
        info.appendChild(name);
        info.appendChild(meta);

        item.appendChild(img);
        item.appendChild(info);
        item.addEventListener('click', () => {
          this.openChatWith(u.id, u.full_name, u.avatar);
        });
        list.appendChild(item);
      });
    } catch (err) {
      console.error('Chat user list error:', err);
    }
  }

  getMessagesBox() {
    return document.getElementById('messagesContainer') || document.getElementById('chat-messages-box');
  }

  async sendChatMessage() {
    const input = document.getElementById('messageInput') || document.getElementById('chat-text-input');
    if (!input) return;
    const text = input.value.trim();
    if (!text) return;
    if (!this.activeChatPartnerId && !this.activeChatPartner) {
      this.showToast('Pick a student from the chat list first.', 'info');
      return;
    }

    const box = this.getMessagesBox();
    if (box) {
      const placeholder = box.querySelector('[data-chat-placeholder]');
      if (placeholder) placeholder.remove();
      const sentBubble = document.createElement('div');
      sentBubble.className = 'chat-bubble sent';
      sentBubble.textContent = text;
      box.appendChild(sentBubble);
      box.scrollTop = box.scrollHeight;
    }
    input.value = '';

    try {
      const res = await this.api('send_message.php', {
        method: 'POST',
        body: {
          receiver_id: this.activeChatPartnerId,
          partner_name: this.activeChatPartner,
          message: text
        }
      });
      if (res && res.message && res.message.id) {
        this.lastChatMessageId = Number(res.message.id);
      }
    } catch (err) {
      console.error('Chat send error:', err);
    }
  }

  /* ==========================================================================
     INTERACTIONS & MODALS
     ========================================================================== */
  async openUserProfileModal(skillOrUser) {
    if (!skillOrUser) return;

    let user = skillOrUser;
    let rawId = skillOrUser.user_id || skillOrUser.id;
    if (typeof rawId === 'string' && rawId.startsWith('tag_')) {
      const parts = rawId.split('_');
      rawId = parts[1];
    }
    const numId = rawId ? Number(rawId) : null;

    // Fetch full user profile dynamically from API if we have an ID
    if (numId && !isNaN(numId) && numId > 0) {
      try {
        const res = await this.api(`api/profile.php?user_id=${numId}`);
        if (res && res.profile) {
          user = { ...skillOrUser, ...res.profile };
        }
      } catch (e) {
        console.warn('Using cached skill user details:', e);
      }
    }

    const instructorName = user.full_name || user.instructor || 'Student';
    const avatar = user.avatar || 'assets/alex_chen.jpg';
    const university = user.university || user.instructorUniversity || 'University';
    const tagline = user.tagline || user.instructorTagline || 'Student & Lifelong Learner';
    const bio = user.bio || user.instructorBio || user.description || 'Passionate about sharing skills and learning together 1-on-1.';
    const rating = user.rating || user.instructorRating || 5.0;
    const exchanges = user.exchanges_count ?? 0;
    const hours = user.hours_taught ?? 0;
    const phone = user.phone || user.instructorPhone || '';
    const fbUrl = user.facebook_url || user.instructorFacebook || '';

    // Populate Header & Info
    const avatarEl = document.getElementById('modal-user-avatar');
    const nameEl = document.getElementById('modal-user-name');
    const uniEl = document.getElementById('modal-user-uni');
    const taglineEl = document.getElementById('modal-user-tagline');
    const ratingEl = document.getElementById('modal-user-rating');
    const exchangesEl = document.getElementById('modal-user-exchanges');
    const hoursEl = document.getElementById('modal-user-hours');
    const bioEl = document.getElementById('modal-user-bio');

    if (avatarEl) avatarEl.src = avatar;
    if (nameEl) nameEl.textContent = instructorName;
    if (uniEl) uniEl.textContent = university;
    if (taglineEl) taglineEl.textContent = tagline;
    if (ratingEl) ratingEl.textContent = Number(rating).toFixed(1);
    if (exchangesEl) exchangesEl.textContent = exchanges;
    if (hoursEl) hoursEl.textContent = `${hours}h`;
    if (bioEl) bioEl.textContent = bio;

    // Populate Contact Buttons
    const btnPhone = document.getElementById('modal-user-btn-phone');
    const txtPhone = document.getElementById('modal-user-phone-text');
    const btnFb = document.getElementById('modal-user-btn-facebook');
    const contactsRow = document.getElementById('modal-user-contacts-row');

    let hasContact = false;
    if (phone && phone.trim()) {
      btnPhone.style.display = 'inline-flex';
      btnPhone.href = `tel:${phone.replace(/[^0-9+]/g, '') || phone}`;
      if (txtPhone) txtPhone.textContent = phone;
      hasContact = true;
    } else {
      btnPhone.style.display = 'none';
    }

    if (fbUrl && fbUrl.trim()) {
      btnFb.style.display = 'inline-flex';
      btnFb.href = fbUrl.startsWith('http') ? fbUrl : `https://${fbUrl}`;
      hasContact = true;
    } else {
      btnFb.style.display = 'none';
    }

    if (contactsRow) {
      contactsRow.style.display = hasContact ? 'flex' : 'none';
    }

    // Populate Skills I Teach Tags
    const teachTagsWrap = document.getElementById('modal-user-teach-tags');
    if (teachTagsWrap) {
      teachTagsWrap.innerHTML = '';
      const teachList = (user.skillsTeach && user.skillsTeach.length > 0) ? user.skillsTeach : (skillOrUser.title ? [skillOrUser.title] : ['Peer Tutoring']);
      teachList.forEach(t => {
        const tag = document.createElement('span');
        tag.className = 'tag-teach';
        tag.textContent = t.endsWith('✓') ? t : `${t} ✓`;
        teachTagsWrap.appendChild(tag);
      });
    }

    // Populate Skills I Want to Learn Tags
    const learnTagsWrap = document.getElementById('modal-user-learn-tags');
    if (learnTagsWrap) {
      learnTagsWrap.innerHTML = '';
      const learnList = (user.skillsLearn && user.skillsLearn.length > 0) ? user.skillsLearn : ['Knowledge Exchange'];
      learnList.forEach(l => {
        const tag = document.createElement('span');
        tag.className = 'tag-learn';
        tag.textContent = l;
        learnTagsWrap.appendChild(tag);
      });
    }

    // Action Buttons
    const isMine = this.currentUser && ((numId && Number(numId) === Number(this.currentUser.id)) || instructorName === this.currentUser.full_name);
    const msgBtn = document.getElementById('modal-user-btn-message');
    const connectBtn = document.getElementById('modal-user-btn-connect');

    if (msgBtn) {
      if (isMine) {
        msgBtn.innerHTML = '<span>👤</span> View My Profile Page';
        msgBtn.onclick = () => {
          this.closeModals();
          this.navigate('profile');
        };
      } else {
        const firstName = instructorName.split(' ')[0];
        msgBtn.innerHTML = `<span>💬</span> Message ${firstName}`;
        msgBtn.onclick = () => {
          this.closeModals();
          this.openChatWith(numId, instructorName, avatar);
        };
      }
    }

    if (connectBtn) {
      if (isMine) {
        connectBtn.innerHTML = '<span>✏️</span> Edit Profile Settings';
        connectBtn.onclick = () => {
          this.closeModals();
          document.getElementById('btn-open-edit-profile').click();
        };
      } else {
        connectBtn.innerHTML = '<span>🤝</span> Request Skill Exchange';
        connectBtn.onclick = () => {
          this.closeModals();
          const targetTitle = (user.skillsTeach && user.skillsTeach[0]) || skillOrUser.title || 'Skill Tutoring';
          const targetCat = skillOrUser.category || 'Development';
          this.openConnectModal(targetTitle, targetCat, instructorName);
        };
      }
    }

    this.openModal(this.modalUserProfile);
  }

  openConnectModal(skillTitle, category, instructor) {
    document.getElementById('connect-target-skill').value = skillTitle;
    document.getElementById('connect-target-instructor').value = instructor;
    document.getElementById('connect-skill-display').value = `${skillTitle} (${category}) with ${instructor}`;
    document.getElementById('modal-connect-subtitle').textContent = `Propose an exchange with ${instructor}.`;
    this.openModal(this.modalConnect);
  }

  openScheduleModal(reqId, senderName, skillTitle) {
    document.getElementById('schedule-req-id').value = reqId;
    document.getElementById('schedule-subtitle').textContent = `Schedule your session with ${senderName} for ${skillTitle}.`;

    // Default next day 2:00 PM
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(14, 0, 0, 0);
    const localIso = new Date(tomorrow.getTime() - tomorrow.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    document.getElementById('schedule-date').value = localIso;

    this.openModal(this.modalSchedule);
  }

  openAddSkillModal(type = 'teach') {
    document.getElementById('add-skill-type').value = type;
    const title = document.getElementById('modal-add-skill-title');
    const subtitle = document.getElementById('modal-add-skill-subtitle');
    if (type === 'teach') {
      title.textContent = 'Add Skill to Teach';
      subtitle.textContent = 'Show other students what skills you can share or tutor.';
    } else {
      title.textContent = 'Add Skill to Learn';
      subtitle.textContent = 'List a skill you want to learn from other students.';
    }
    this.openModal(this.modalAddSkill);
  }

  /**
   * Alias for toggleChat() — kept for backward compatibility.
   * All internal call-sites should prefer toggleChat().
   */
  openChat(partnerName) {
    this.toggleChat(partnerName);
  }

  messagesQuery() {
    if (this.activeChatPartnerId) {
      return `get_messages.php?receiver_id=${this.activeChatPartnerId}`;
    }
    return `get_messages.php?partner_name=${encodeURIComponent(this.activeChatPartner || '')}`;
  }

  async loadMessages() {
    const box = this.getMessagesBox();
    const avatarEl = document.getElementById('chat-header-avatar');
    if (!box) return;
    if (!this.activeChatPartnerId && !this.activeChatPartner) return;

    try {
      const res = await this.api(this.messagesQuery());

      if (res && res.partner) {
        if (avatarEl && res.partner.avatar) avatarEl.src = res.partner.avatar;
        if (res.partner.id) this.activeChatPartnerId = Number(res.partner.id);
        if (res.partner.full_name) {
          this.activeChatPartner = res.partner.full_name;
          const nameEl = document.getElementById('chat-header-name');
          if (nameEl) nameEl.textContent = res.partner.full_name;
        }
      }

      if (res && res.messages) {
        box.innerHTML = '';

        if (res.messages.length === 0) {
          box.innerHTML = `<div data-chat-placeholder style="text-align:center;color:var(--text-muted);font-size:0.85rem;padding:2rem 1rem;">No previous messages yet. Send a greeting to start chatting!</div>`;
        } else {
          res.messages.forEach(msg => {
            const bubble = document.createElement('div');
            bubble.className = `chat-bubble ${msg.direction}`;
            bubble.textContent = msg.message;
            box.appendChild(bubble);
          });
          const lastMsg = res.messages[res.messages.length - 1];
          if (lastMsg) this.lastChatMessageId = Number(lastMsg.id);
        }

        box.scrollTop = box.scrollHeight;
      }
    } catch (err) {
      console.error('Error loading chat messages:', err);
    }
  }

  async loadChatMessages() {
    return this.loadMessages();
  }

  async pollChatMessages() {
    if (!this.isLoggedIn) return;
    if (this.chatPanel !== 'conversation') return;
    const box = this.getMessagesBox();
    if (!box) return;

    try {
      const res = await this.api(this.messagesQuery());
      if (!res || !res.messages || res.messages.length === 0) return;

      const newMessages = res.messages.filter(m => Number(m.id) > this.lastChatMessageId);
      if (newMessages.length === 0) return;

      const placeholder = box.querySelector('[data-chat-placeholder]');
      if (placeholder) placeholder.remove();

      newMessages.forEach(msg => {
        const bubble = document.createElement('div');
        bubble.className = `chat-bubble ${msg.direction}`;
        bubble.textContent = msg.message;
        box.appendChild(bubble);
      });

      const lastMsg = res.messages[res.messages.length - 1];
      if (lastMsg) this.lastChatMessageId = Number(lastMsg.id);

      box.scrollTop = box.scrollHeight;
    } catch (err) {
      console.warn('Chat poll error (silent):', err);
    }
  }

  openModal(modalElement) {
    this.closeModals();
    if (modalElement) {
      modalElement.classList.add('open');
    }
  }

  closeModals() {
    const modals = document.querySelectorAll('.modal-overlay');
    modals.forEach(m => m.classList.remove('open'));
  }

  showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast-message ${type}`;
    const icon = type === 'success' ? '✓' : type === 'info' ? 'ℹ' : '🔔';
    toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;

    container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 4000);
  }
}

// Global App Initialization
document.addEventListener('DOMContentLoaded', () => {
  window.app = new SkillverseApp();
});
