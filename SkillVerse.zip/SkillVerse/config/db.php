<?php
/**
 * Skillverse Database Connection & Global Backend Utilities
 * Configured for XAMPP (MySQL localhost:3306) with auto-password detection ('root' or '')
 */

// Start session if not active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Configuration Constants
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'skillverse_db');
define('DB_USER', 'root');

/**
 * Returns a singleton PDO connection instance.
 * Automatically tries root password 'root' and '' to ensure 100% compatibility.
 */
function getDBConnection() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $passwordsToTry = ['root', ''];
    $lastError = null;

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ];

    foreach ($passwordsToTry as $pass) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, $pass, $options);

            // Auto-migration: ensure phone and facebook_url columns exist
            try {
                $cols = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'phone'")->fetch();
                if (!$cols) {
                    $pdo->exec("ALTER TABLE `users` ADD COLUMN `phone` VARCHAR(50) DEFAULT NULL AFTER `avatar`");
                }
                $colsFb = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'facebook_url'")->fetch();
                if (!$colsFb) {
                    $pdo->exec("ALTER TABLE `users` ADD COLUMN `facebook_url` VARCHAR(255) DEFAULT NULL AFTER `phone`");
                }
                // Add new social media contact columns
                $colsPhoneNumber = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'phone_number'")->fetch();
                if (!$colsPhoneNumber) {
                    $pdo->exec("ALTER TABLE `users` ADD COLUMN `phone_number` VARCHAR(20) DEFAULT NULL AFTER `phone`");
                }
                $colsMessenger = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'messenger_username'")->fetch();
                if (!$colsMessenger) {
                    $pdo->exec("ALTER TABLE `users` ADD COLUMN `messenger_username` VARCHAR(100) DEFAULT NULL AFTER `phone_number`");
                }
                $colsInstagram = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'instagram_username'")->fetch();
                if (!$colsInstagram) {
                    $pdo->exec("ALTER TABLE `users` ADD COLUMN `instagram_username` VARCHAR(100) DEFAULT NULL AFTER `messenger_username`");
                }
            } catch (Exception $ign) {}

            return $pdo;
        } catch (PDOException $e) {
            $lastError = $e;
            // If the database itself doesn't exist (error 1049), report setup needed
            if ($e->getCode() == 1049) {
                jsonError("Database '" . DB_NAME . "' does not exist yet. Please visit http://localhost/SkillVerse/setup.php to initialize it.", 500, ['setup_required' => true]);
            }
        }
    }

    jsonError("Database connection failed: " . ($lastError ? $lastError->getMessage() : 'Access denied.'), 500);
}

/**
 * Send standard JSON Response
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Send standard JSON Error Response
 */
function jsonError($message, $statusCode = 400, $extra = []) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge([
        'success' => false,
        'error'   => $message
    ], $extra), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Read request payload from JSON body or POST form data
 */
function getRequestData() {
    $contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
    if (strpos($contentType, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    return $_POST;
}

/**
 * Get current logged in user ID from Session
 */
function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
}

/**
 * Require user to be logged in
 */
function requireAuth() {
    $userId = getCurrentUserId();
    if (!$userId) {
        jsonError("Authentication required. Please log in.", 401);
    }
    return $userId;
}

/**
 * Fetch full profile of current user with teach/learn skill tags
 */
function getUserFullProfile($userId, $pdo = null) {
    if (!$pdo) $pdo = getDBConnection();
    
    $stmt = $pdo->prepare("
        SELECT id, full_name, email, university, tagline, bio, avatar, phone, phone_number, messenger_username, instagram_username, facebook_url, rating, hours_taught, hours_learned, exchanges_count, created_at 
        FROM users 
        WHERE id = ?
    ");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    if (!$user) return null;

    // Fetch Teach & Learn Tags
    $tagStmt = $pdo->prepare("SELECT skill_name, tag_type FROM user_skill_tags WHERE user_id = ? ORDER BY id ASC");
    $tagStmt->execute([$userId]);
    $tags = $tagStmt->fetchAll();

    $user['skillsTeach'] = [];
    $user['skillsLearn'] = [];

    foreach ($tags as $t) {
        if ($t['tag_type'] === 'teach') {
            $user['skillsTeach'][] = $t['skill_name'];
        } else {
            $user['skillsLearn'][] = $t['skill_name'];
        }
    }

    // Fetch marketplace skills for this user
    $skillsStmt = $pdo->prepare("SELECT id, title, category, mastery_level AS masteryLevel, description, image FROM skills WHERE user_id = ? ORDER BY id DESC");
    $skillsStmt->execute([$userId]);
    $user['marketplaceSkills'] = $skillsStmt->fetchAll();

    return $user;
}

/**
 * Format relative time (e.g. "2h ago", "1d ago")
 */
function timeElapsedString($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    if ($diff->d > 0) {
        return $diff->d . ($diff->d === 1 ? 'd ago' : 'd ago');
    }
    if ($diff->h > 0) {
        return $diff->h . 'h ago';
    }
    if ($diff->i > 0) {
        return $diff->i . 'm ago';
    }
    return 'Just now';
}
