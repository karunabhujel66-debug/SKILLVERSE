<?php
/**
 * Skillverse mysqli connection (XAMPP)
 * Used by the chat PHP files. Tries password "root" then empty string.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function getMysqli() {
    static $conn = null;
    if ($conn instanceof mysqli) {
        return $conn;
    }

    $host = '127.0.0.1';
    $user = 'root';
    $db   = 'skillverse_db';
    $port = 3306;
    $passwords = ['root', ''];

    foreach ($passwords as $pass) {
        $try = @new mysqli($host, $user, $pass, $db, $port);
        if ($try && !$try->connect_error) {
            $try->set_charset('utf8mb4');
            $conn = $try;
            return $conn;
        }
    }

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'error'   => 'Database connection failed. Start MySQL in XAMPP and run setup.php.'
    ]);
    exit;
}

function chatJson($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

function chatRequireLogin() {
    if (!isset($_SESSION['user_id']) || (int)$_SESSION['user_id'] <= 0) {
        chatJson(['success' => false, 'error' => 'Please log in first.'], 401);
    }
    return (int)$_SESSION['user_id'];
}

function chatReadBody() {
    $contentType = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    if (stripos($contentType, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    return $_POST;
}
