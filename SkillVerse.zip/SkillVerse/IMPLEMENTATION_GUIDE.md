# Skillverse Platform Update - Implementation Guide

## Overview
This guide provides implementation details for the new features added to Skillverse:
1. Social Media Contact Buttons (WhatsApp, Messenger, Instagram)
2. Compulsory Skill Image Upload with PHP Validation
3. Profile Contact Information Fields
4. Database schema updates

---

## 1. DATABASE CHANGES

### SQL Query - Add Contact Columns to Users Table
```sql
-- Add these columns to users table:
ALTER TABLE `users` ADD COLUMN `phone_number` VARCHAR(20) DEFAULT NULL AFTER `phone`;
ALTER TABLE `users` ADD COLUMN `messenger_username` VARCHAR(100) DEFAULT NULL AFTER `phone_number`;
ALTER TABLE `users` ADD COLUMN `instagram_username` VARCHAR(100) DEFAULT NULL AFTER `messenger_username`;
```

**Columns Added:**
- `phone_number` (VARCHAR 20) - For WhatsApp contact
- `messenger_username` (VARCHAR 100) - For Facebook Messenger
- `instagram_username` (VARCHAR 100) - For Instagram DM

**Note:** These are auto-added via `db.php` auto-migration when DB connection is established.

---

## 2. FILE UPLOAD HANDLING (PHP)

### Endpoint: `/api/upload_skill_image.php`

**Purpose:** Handle skill image uploads with validation

**Method:** POST

**Accepts:** Multipart form data with file

**Validation Rules:**
- File is required (no empty uploads)
- Only JPG, JPEG, PNG allowed
- Maximum file size: 5MB
- File is moved to `/uploads/` directory
- Filename is renamed using: `skill_<userId>_<timestamp>_<randomString>.ext`

**Request:**
```php
POST /api/upload_skill_image.php
Content-Type: multipart/form-data

[File Upload]
image: <file>
```

**Success Response (201):**
```json
{
  "success": true,
  "message": "Image uploaded successfully.",
  "file_path": "uploads/skill_1_1693456789_abc123def456.jpg",
  "file_name": "skill_1_1693456789_abc123def456.jpg"
}
```

**Error Response (400):**
```json
{
  "success": false,
  "error": "Image is required for skill upload"
}
```

---

## 3. SKILL CREATION VALIDATION (PHP)

### File: `/api/skills.php` (POST method)

**Changes:**
- Title validation: Required, cannot be empty
- Description validation: Required, cannot be empty
- Image validation: Required, must be provided (file_path from upload)

**Validation Logic:**
```php
if (empty($title)) {
    jsonError('Skill title is required.');
}

if (empty($description)) {
    jsonError('Skill description is required.');
}

if (empty($image)) {
    jsonError('Image is required for skill upload');
}
```

**Workflow:**
1. User uploads image via `/api/upload_skill_image.php` → Gets file_path
2. User submits skill form with title, description, and image_path
3. Server validates all three fields
4. Skill is created with uploaded image path in database

---

## 4. PROFILE UPDATE WITH SOCIAL CONTACTS (PHP)

### File: `/api/profile.php` (POST action=update)

**New Fields in Profile Update:**
```json
{
  "action": "update",
  "full_name": "John Doe",
  "tagline": "Computer Science Major",
  "bio": "Passionate developer",
  "phone": "+1-555-1234",
  "phone_number": "+1-555-1234567",
  "messenger_username": "john.doe",
  "instagram_username": "johndoe_official",
  "facebook_url": "https://facebook.com/johndoe"
}
```

**Database Update Query:**
```php
UPDATE users 
SET full_name = ?, 
    tagline = ?, 
    bio = ?, 
    phone = ?, 
    phone_number = ?, 
    messenger_username = ?, 
    instagram_username = ?, 
    facebook_url = ?
WHERE id = ?
```

---

## 5. CONTACT BUTTON LINKS

### WhatsApp Link Format
```html
https://wa.me/<phone_number>

<!-- Example -->
https://wa.me/15551234567

<!-- With optional message -->
https://wa.me/15551234567?text=Hello%20I%20would%20like%20to%20learn%20about%20your%20skill
```

### Facebook Messenger Link Format
```html
https://m.me/<username>

<!-- Example -->
https://m.me/john.doe

<!-- Direct conversation -->
https://m.me/<username>?text=Hello%20I%20am%20interested%20in%20your%20skill
```

### Instagram Link Format
```html
https://instagram.com/<username>

<!-- Example -->
https://instagram.com/johndoe_official
```

---

## 6. HTML/CSS - CONTACT BUTTONS ON SKILL CARDS

### HTML Structure
```html
<!-- Skill Card Contact Section -->
<div class="skill-card-contact-section">
  <div class="contact-label">📞 Contact Instructor:</div>
  
  <div class="contact-buttons">
    <!-- WhatsApp Button -->
    <a href="https://wa.me/15551234567" 
       target="_blank" 
       rel="noopener noreferrer"
       class="contact-btn contact-btn-whatsapp"
       title="Chat on WhatsApp">
      <span class="btn-icon">💬</span>
      <span class="btn-text">WhatsApp</span>
    </a>

    <!-- Messenger Button -->
    <a href="https://m.me/john.doe" 
       target="_blank" 
       rel="noopener noreferrer"
       class="contact-btn contact-btn-messenger"
       title="Chat on Messenger">
      <span class="btn-icon">💙</span>
      <span class="btn-text">Messenger</span>
    </a>

    <!-- Instagram Button (Optional) -->
    <a href="https://instagram.com/johndoe_official" 
       target="_blank" 
       rel="noopener noreferrer"
       class="contact-btn contact-btn-instagram"
       title="Follow on Instagram">
      <span class="btn-icon">📷</span>
      <span class="btn-text">Instagram</span>
    </a>
  </div>
</div>
```

### CSS Styling
```css
.skill-card-contact-section {
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid var(--border-light);
}

.contact-label {
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--text-muted);
  margin-bottom: 0.75rem;
}

.contact-buttons {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}

.contact-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  padding: 0.5rem 1rem;
  border-radius: 0.375rem;
  text-decoration: none;
  font-size: 0.85rem;
  font-weight: 600;
  transition: all 0.2s ease;
  border: none;
  cursor: pointer;
}

.contact-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* WhatsApp - Green */
.contact-btn-whatsapp {
  background-color: #25D366;
  color: white;
}

.contact-btn-whatsapp:hover {
  background-color: #1e9a54;
}

/* Messenger - Blue */
.contact-btn-messenger {
  background-color: #0084FF;
  color: white;
}

.contact-btn-messenger:hover {
  background-color: #0073E6;
}

/* Instagram - Pink Gradient */
.contact-btn-instagram {
  background: linear-gradient(45deg, #FD5949, #D6249F, #285AEB);
  color: white;
}

.contact-btn-instagram:hover {
  opacity: 0.9;
}

.btn-icon {
  font-size: 1.1rem;
}

.btn-text {
  display: none;
}

/* Show text on larger screens */
@media (min-width: 640px) {
  .btn-text {
    display: inline;
  }
}
```

---

## 7. SKILL UPLOAD FORM - HTML & JAVASCRIPT

### HTML Form
```html
<div class="skill-upload-form">
  <h3>Share a New Skill</h3>
  
  <form id="skill-upload-form">
    <!-- Skill Title -->
    <div class="form-group">
      <label for="skill-title">Skill Title *</label>
      <input type="text" 
             id="skill-title" 
             name="title" 
             placeholder="e.g., Python Programming"
             required />
      <span class="error-msg" id="error-title"></span>
    </div>

    <!-- Skill Category -->
    <div class="form-group">
      <label for="skill-category">Category *</label>
      <select id="skill-category" name="category" required>
        <option value="Development">Development</option>
        <option value="Design">Design</option>
        <option value="Photography">Photography</option>
        <option value="Business">Business</option>
        <option value="Language">Language</option>
        <option value="Music & Audio">Music & Audio</option>
        <option value="Other">Other</option>
      </select>
    </div>

    <!-- Mastery Level -->
    <div class="form-group">
      <label for="skill-mastery">Mastery Level *</label>
      <select id="skill-mastery" name="masteryLevel" required>
        <option value="Beginner">Beginner</option>
        <option value="Intermediate">Intermediate</option>
        <option value="Advanced">Advanced</option>
        <option value="Expert">Expert</option>
      </select>
    </div>

    <!-- Description -->
    <div class="form-group">
      <label for="skill-description">Description *</label>
      <textarea id="skill-description" 
                name="description" 
                placeholder="Describe what you'll teach..."
                rows="4"
                required></textarea>
      <span class="error-msg" id="error-description"></span>
    </div>

    <!-- Image Upload -->
    <div class="form-group">
      <label for="skill-image">Skill Image *</label>
      <div class="file-upload-area">
        <input type="file" 
               id="skill-image" 
               name="image" 
               accept=".jpg,.jpeg,.png"
               required />
        <label for="skill-image" class="file-upload-label">
          <span class="upload-icon">📸</span>
          <span class="upload-text">Click to upload or drag & drop</span>
          <span class="upload-hint">JPG, JPEG, PNG (Max 5MB)</span>
        </label>
        <div id="image-preview" class="image-preview" style="display: none;">
          <img id="preview-img" src="" alt="Preview" />
          <button type="button" class="btn-remove-image">Remove</button>
        </div>
      </div>
      <span class="error-msg" id="error-image"></span>
    </div>

    <!-- Submit Button -->
    <button type="submit" class="btn-submit">Share Skill</button>
  </form>
</div>
```

### CSS for Upload Form
```css
.file-upload-area {
  position: relative;
  border: 2px dashed var(--border-color);
  border-radius: 0.5rem;
  padding: 2rem;
  text-align: center;
  cursor: pointer;
  transition: all 0.2s ease;
}

.file-upload-area:hover {
  border-color: var(--brand-dark-green);
  background-color: rgba(34, 197, 94, 0.05);
}

.file-upload-area input[type="file"] {
  display: none;
}

.file-upload-label {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
}

.upload-icon {
  font-size: 2rem;
}

.upload-text {
  font-weight: 600;
  color: var(--text-primary);
}

.upload-hint {
  font-size: 0.85rem;
  color: var(--text-muted);
}

.image-preview {
  position: relative;
  margin-top: 1rem;
}

.image-preview img {
  max-width: 100%;
  max-height: 300px;
  border-radius: 0.375rem;
}

.btn-remove-image {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  background-color: rgba(220, 38, 38, 0.9);
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 0.25rem;
  cursor: pointer;
  font-size: 0.85rem;
  font-weight: 600;
}

.error-msg {
  display: block;
  color: #DC2626;
  font-size: 0.85rem;
  margin-top: 0.25rem;
}
```

### JavaScript - Form Handling & Upload
```javascript
// Initialize form handlers
document.addEventListener('DOMContentLoaded', function() {
  const uploadForm = document.getElementById('skill-upload-form');
  const imageInput = document.getElementById('skill-image');
  const imagePreview = document.getElementById('image-preview');
  const previewImg = document.getElementById('preview-img');
  const removeImageBtn = document.querySelector('.btn-remove-image');

  // Image preview on selection
  imageInput.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
      // Validate file type
      if (!['image/jpeg', 'image/png'].includes(file.type)) {
        showError('image', 'Only JPG, JPEG, and PNG files are allowed.');
        return;
      }

      // Validate file size
      if (file.size > 5 * 1024 * 1024) {
        showError('image', 'File size must not exceed 5MB.');
        return;
      }

      // Show preview
      const reader = new FileReader();
      reader.onload = function(e) {
        previewImg.src = e.target.result;
        imagePreview.style.display = 'block';
        clearError('image');
      };
      reader.readAsDataURL(file);
    }
  });

  // Remove image
  removeImageBtn?.addEventListener('click', function() {
    imageInput.value = '';
    imagePreview.style.display = 'none';
  });

  // Form submission
  uploadForm.addEventListener('submit', async function(e) {
    e.preventDefault();

    // Validate form
    const title = document.getElementById('skill-title').value.trim();
    const description = document.getElementById('skill-description').value.trim();
    const file = imageInput.files[0];

    if (!title) {
      showError('title', 'Skill title is required.');
      return;
    }
    if (!description) {
      showError('description', 'Description is required.');
      return;
    }
    if (!file) {
      showError('image', 'Image is required for skill upload');
      return;
    }

    try {
      // Step 1: Upload image
      const uploadFormData = new FormData();
      uploadFormData.append('image', file);

      const uploadResponse = await fetch('/api/upload_skill_image.php', {
        method: 'POST',
        body: uploadFormData
      });

      const uploadResult = await uploadResponse.json();

      if (!uploadResult.success) {
        showError('image', uploadResult.error || 'Failed to upload image');
        return;
      }

      // Step 2: Create skill with uploaded image path
      const category = document.getElementById('skill-category').value;
      const mastery = document.getElementById('skill-mastery').value;
      const imagePath = uploadResult.file_path;

      const skillData = {
        title,
        description,
        category,
        masteryLevel: mastery,
        image: imagePath
      };

      const skillResponse = await fetch('/api/skills.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(skillData)
      });

      const skillResult = await skillResponse.json();

      if (!skillResult.success) {
        alert('Error: ' + (skillResult.error || 'Failed to create skill'));
        return;
      }

      alert('Skill published successfully!');
      uploadForm.reset();
      imagePreview.style.display = 'none';
      // Refresh skills list or redirect
      location.reload();

    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. Please try again.');
    }
  });

  // Error/success helpers
  function showError(fieldName, message) {
    const errorElement = document.getElementById(`error-${fieldName}`);
    if (errorElement) {
      errorElement.textContent = message;
    }
  }

  function clearError(fieldName) {
    const errorElement = document.getElementById(`error-${fieldName}`);
    if (errorElement) {
      errorElement.textContent = '';
    }
  }
});
```

---

## 8. PROFILE EDIT FORM - HTML & JAVASCRIPT

### HTML for Profile Edit Form
```html
<div class="profile-edit-form">
  <h3>Edit Profile</h3>
  
  <form id="profile-edit-form">
    <!-- Personal Info Section -->
    <fieldset>
      <legend>Personal Information</legend>
      
      <div class="form-group">
        <label for="full-name">Full Name *</label>
        <input type="text" id="full-name" name="full_name" required />
      </div>

      <div class="form-group">
        <label for="tagline">Tagline</label>
        <input type="text" id="tagline" name="tagline" placeholder="e.g., CS Major • Python Expert" />
      </div>

      <div class="form-group">
        <label for="bio">Bio</label>
        <textarea id="bio" name="bio" rows="4" placeholder="Tell us about yourself..."></textarea>
      </div>
    </fieldset>

    <!-- Contact Info Section -->
    <fieldset>
      <legend>Contact & Social Media</legend>
      
      <div class="form-group">
        <label for="phone">Phone (General)</label>
        <input type="tel" id="phone" name="phone" placeholder="+1 (555) 123-4567" />
      </div>

      <div class="form-group">
        <label for="phone-number">WhatsApp Phone Number</label>
        <input type="tel" id="phone-number" name="phone_number" placeholder="+1 5551234567" />
        <small>Format: +1 5551234567 (without spaces or dashes)</small>
      </div>

      <div class="form-group">
        <label for="messenger-username">Facebook Messenger Username</label>
        <input type="text" id="messenger-username" name="messenger_username" placeholder="john.doe" />
        <small>Your Facebook username or page name</small>
      </div>

      <div class="form-group">
        <label for="instagram-username">Instagram Username</label>
        <input type="text" id="instagram-username" name="instagram_username" placeholder="johndoe_official" />
        <small>Your Instagram @username (without @)</small>
      </div>

      <div class="form-group">
        <label for="facebook-url">Facebook Profile URL</label>
        <input type="url" id="facebook-url" name="facebook_url" placeholder="https://facebook.com/johndoe" />
      </div>
    </fieldset>

    <!-- Buttons -->
    <div class="form-actions">
      <button type="submit" class="btn-primary">Save Changes</button>
      <button type="button" class="btn-secondary" onclick="cancelEdit()">Cancel</button>
    </div>
  </form>
</div>
```

### CSS for Profile Form
```css
fieldset {
  border: 1px solid var(--border-light);
  border-radius: 0.375rem;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
}

legend {
  padding: 0 0.5rem;
  font-weight: 600;
  color: var(--text-primary);
}

fieldset > div:last-child {
  margin-bottom: 0;
}

small {
  display: block;
  font-size: 0.75rem;
  color: var(--text-muted);
  margin-top: 0.25rem;
}

.form-actions {
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 2rem;
  padding-top: 1.5rem;
  border-top: 1px solid var(--border-light);
}
```

### JavaScript - Profile Form Handler
```javascript
document.addEventListener('DOMContentLoaded', function() {
  const profileForm = document.getElementById('profile-edit-form');
  
  if (!profileForm) return;

  // Load current profile data
  async function loadProfile() {
    try {
      const response = await fetch('/api/profile.php');
      const result = await response.json();
      
      if (!result.success) {
        alert('Failed to load profile: ' + result.error);
        return;
      }

      const profile = result.profile;

      // Populate form fields
      document.getElementById('full-name').value = profile.full_name || '';
      document.getElementById('tagline').value = profile.tagline || '';
      document.getElementById('bio').value = profile.bio || '';
      document.getElementById('phone').value = profile.phone || '';
      document.getElementById('phone-number').value = profile.phone_number || '';
      document.getElementById('messenger-username').value = profile.messenger_username || '';
      document.getElementById('instagram-username').value = profile.instagram_username || '';
      document.getElementById('facebook-url').value = profile.facebook_url || '';
      
    } catch (error) {
      console.error('Error loading profile:', error);
    }
  }

  // Submit form
  profileForm.addEventListener('submit', async function(e) {
    e.preventDefault();

    const fullName = document.getElementById('full-name').value.trim();
    if (!fullName) {
      alert('Full name is required.');
      return;
    }

    const updateData = {
      action: 'update',
      full_name: fullName,
      tagline: document.getElementById('tagline').value.trim(),
      bio: document.getElementById('bio').value.trim(),
      phone: document.getElementById('phone').value.trim(),
      phone_number: document.getElementById('phone-number').value.trim(),
      messenger_username: document.getElementById('messenger-username').value.trim(),
      instagram_username: document.getElementById('instagram-username').value.trim(),
      facebook_url: document.getElementById('facebook-url').value.trim()
    };

    try {
      const response = await fetch('/api/profile.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updateData)
      });

      const result = await response.json();

      if (!result.success) {
        alert('Error: ' + (result.error || 'Failed to update profile'));
        return;
      }

      alert('Profile updated successfully!');
      // Refresh page or update UI
      location.reload();

    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. Please try again.');
    }
  });

  // Load profile on page load
  loadProfile();
});

function cancelEdit() {
  if (confirm('Discard changes?')) {
    location.href = '#profile';
  }
}
```

---

## 9. RENDERING CONTACT BUTTONS IN JAVASCRIPT

### Function to Generate Contact URLs
```javascript
function getContactUrls(instructor) {
  const urls = {
    whatsapp: null,
    messenger: null,
    instagram: null
  };

  if (instructor.instructorPhoneNumber) {
    urls.whatsapp = `https://wa.me/${instructor.instructorPhoneNumber.replace(/\D/g, '')}`;
  }

  if (instructor.instructorMessenger) {
    urls.messenger = `https://m.me/${instructor.instructorMessenger}`;
  }

  if (instructor.instructorInstagram) {
    urls.instagram = `https://instagram.com/${instructor.instructorInstagram}`;
  }

  return urls;
}

// Render contact buttons in skill card
function renderContactButtons(skill) {
  const urls = getContactUrls(skill);
  let html = '<div class="skill-card-contact-section">';
  html += '<div class="contact-label">📞 Contact Instructor:</div>';
  html += '<div class="contact-buttons">';

  if (urls.whatsapp) {
    html += `
      <a href="${urls.whatsapp}" 
         target="_blank" rel="noopener noreferrer"
         class="contact-btn contact-btn-whatsapp"
         title="Chat on WhatsApp">
        <span class="btn-icon">💬</span>
        <span class="btn-text">WhatsApp</span>
      </a>
    `;
  }

  if (urls.messenger) {
    html += `
      <a href="${urls.messenger}" 
         target="_blank" rel="noopener noreferrer"
         class="contact-btn contact-btn-messenger"
         title="Chat on Messenger">
        <span class="btn-icon">💙</span>
        <span class="btn-text">Messenger</span>
      </a>
    `;
  }

  if (urls.instagram) {
    html += `
      <a href="${urls.instagram}" 
         target="_blank" rel="noopener noreferrer"
         class="contact-btn contact-btn-instagram"
         title="Follow on Instagram">
        <span class="btn-icon">📷</span>
        <span class="btn-text">Instagram</span>
      </a>
    `;
  }

  html += '</div></div>';
  return html;
}
```

---

## 10. VALIDATION SUMMARY

### PHP Validation Rules
| Field | Rule | Error Message |
|-------|------|---------------|
| Title | Required, not empty | "Skill title is required." |
| Description | Required, not empty | "Skill description is required." |
| Image | Required, must have file path | "Image is required for skill upload" |
| File Type | jpg, jpeg, png only | "Only JPG, JPEG, and PNG files are allowed." |
| File Size | Max 5MB | "File size must not exceed 5MB." |

### Front-end Validation (JavaScript)
- Check file type before upload
- Check file size before upload
- Show preview after selection
- Validate form fields before submission
- Show error messages to user

---

## 11. ERROR HANDLING

### File Upload Errors
```php
// No file provided
"Image is required for skill upload"

// Invalid file type
"Only JPG, JPEG, and PNG files are allowed."

// File too large
"File size must not exceed 5MB."

// Upload failed
"Failed to save uploaded file."
```

### Skill Creation Errors
```php
// Empty title
"Skill title is required."

// Empty description
"Skill description is required."

// No image provided
"Image is required for skill upload"
```

---

## 12. TESTING CHECKLIST

- [ ] Database columns created (phone_number, messenger_username, instagram_username)
- [ ] File upload accepts only jpg, jpeg, png
- [ ] File upload rejects files larger than 5MB
- [ ] File upload stores images in /uploads/ directory
- [ ] Skill creation requires title, description, and image
- [ ] Profile can be updated with social media contacts
- [ ] Contact buttons appear on skill cards
- [ ] Contact links work correctly (test on mobile for WhatsApp)
- [ ] Image preview works in upload form
- [ ] All validation messages display correctly
- [ ] Auto-migration creates new columns on first connection

---

## 13. SUPPORT & TROUBLESHOOTING

### Images not uploading?
- Check `/uploads/` directory exists and has write permissions
- Verify file size is under 5MB
- Check file format is jpg, jpeg, or png

### Contact buttons not showing?
- Ensure social media fields are filled in user profile
- Check URLs are being generated correctly in JavaScript
- Verify CSS is loaded for button styling

### Database errors?
- Run `/setup.php` to initialize/reset database
- Check database connection in `/config/db.php`
- Verify MySQL is running and accessible

---

**Last Updated:** 2026-08-31
