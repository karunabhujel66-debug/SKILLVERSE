<?php
// Skillverse App Entry Point
require_once __DIR__ . '/index.html';
