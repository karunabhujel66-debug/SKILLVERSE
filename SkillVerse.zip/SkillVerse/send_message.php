<?php
/**
 * Insert a chat message and create a notification for the receiver.
 */

require_once __DIR__ . '/config/mysqli.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    chatJson(['success' => false, 'error' => 'POST only.'], 405);
}

$userId = chatRequireLogin();
$db = getMysqli();
$data = chatReadBody();

$receiverId = 0;
if (!empty($data['receiver_id'])) {
    $receiverId = (int)$data['receiver_id'];
}

$partnerName = isset($data['partner_name']) ? trim($data['partner_name']) : '';
$text = '';
if (isset($data['message'])) {
    $text = trim($data['message']);
} elseif (isset($data['text'])) {
    $text = trim($data['text']);
}

if ($text === '') {
    chatJson(['success' => false, 'error' => 'Message cannot be empty.']);
}

if ($receiverId <= 0 && $partnerName !== '') {
    $like = '%' . $db->real_escape_string($partnerName) . '%';
    $res = $db->query("SELECT id FROM users WHERE full_name LIKE '$like' OR email LIKE '$like' LIMIT 1");
    if ($res && $row = $res->fetch_assoc()) {
        $receiverId = (int)$row['id'];
    }
}

if ($receiverId <= 0) {
    chatJson(['success' => false, 'error' => 'Please choose a student to message.']);
}

if ($receiverId === $userId) {
    chatJson(['success' => false, 'error' => 'You cannot message yourself.']);
}

$safeText = $db->real_escape_string($text);
$ok = $db->query("
    INSERT INTO messages (sender_id, receiver_id, message, is_read)
    VALUES ($userId, $receiverId, '$safeText', 0)
");

if (!$ok) {
    chatJson(['success' => false, 'error' => 'Could not save message.'], 500);
}

$msgId = (int)$db->insert_id;

$senderName = 'A student';
$me = $db->query("SELECT full_name FROM users WHERE id = $userId LIMIT 1");
if ($me && $row = $me->fetch_assoc()) {
    $senderName = $row['full_name'];
}

$preview = $text;
if (strlen($preview) > 80) {
    $preview = substr($preview, 0, 80) . '...';
}

$notifTitle = $db->real_escape_string('New Message');
$notifText = $db->real_escape_string($senderName . ': ' . $preview);
$db->query("
    INSERT INTO notifications (user_id, title, message, icon, is_read)
    VALUES ($receiverId, '$notifTitle', '$notifText', '💬', 0)
");

chatJson([
    'success' => true,
    'message' => [
        'id'          => $msgId,
        'sender_id'   => $userId,
        'receiver_id' => $receiverId,
        'message'     => $text,
        'direction'   => 'sent',
        'created_at' => date('Y-m-d H:i:s')
    ]
], 201);
