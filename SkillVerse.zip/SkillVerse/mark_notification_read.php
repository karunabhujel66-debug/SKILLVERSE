<?php
/**
 * Mark one notification (or all) as read.
 */

require_once __DIR__ . '/config/mysqli.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    chatJson(['success' => false, 'error' => 'POST only.'], 405);
}

$userId = chatRequireLogin();
$db = getMysqli();
$data = chatReadBody();

$notifId = 0;
if (!empty($data['id'])) {
    $notifId = (int)$data['id'];
}

$markAll = !empty($data['all']);

if ($notifId > 0) {
    $db->query("UPDATE notifications SET is_read = 1 WHERE id = $notifId AND user_id = $userId");
} else {
    $db->query("UPDATE notifications SET is_read = 1 WHERE user_id = $userId");
}

chatJson([
    'success' => true,
    'message' => 'Notifications updated.'
]);
