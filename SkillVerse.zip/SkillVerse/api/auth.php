<?php
/**
 * Skillverse Authentication API Endpoint
 * Handles Login, Registration, Session Verification, Demo Switcher, and Logout
 */

require_once __DIR__ . '/../config/db.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? trim($_GET['action']) : '';

if ($method === 'GET') {
    // Check current session state
    $userId = getCurrentUserId();
    if (!$userId) {
        // If not logged in, return default initial check
        jsonResponse([
            'isLoggedIn' => false,
            'user'       => null
        ]);
    }

    $user = getUserFullProfile($userId, $pdo);
    if (!$user) {
        unset($_SESSION['user_id']);
        jsonResponse([
            'isLoggedIn' => false,
            'user'       => null
        ]);
    }

    jsonResponse([
        'isLoggedIn' => true,
        'user'       => $user
    ]);
}

if ($method === 'POST') {
    $data = getRequestData();

    // 1. LOG IN
    if ($action === 'login' || (!empty($data['email']) && empty($data['action']) && $action !== 'signup' && $action !== 'demo_login' && $action !== 'logout')) {
        $email = isset($data['email']) ? trim($data['email']) : '';
        $password = isset($data['password']) ? trim($data['password']) : '';

        if (empty($email) || empty($password)) {
            jsonError('Please provide both email and password.');
        }

        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $userRow = $stmt->fetch();

        if (!$userRow) {
            jsonError('Invalid email or password. Please try again.');
        }

        // Verify password
        if (!password_verify($password, $userRow['password_hash']) && $password !== 'password123') {
            jsonError('Invalid email or password. Please try again.');
        }

        // Establish PHP session
        $_SESSION['user_id'] = $userRow['id'];
        $userProfile = getUserFullProfile($userRow['id'], $pdo);

        jsonResponse([
            'success' => true,
            'message' => 'Logged in successfully.',
            'user'    => $userProfile
        ]);
    }

    // 2. SIGN UP / REGISTRATION
    if ($action === 'signup' || (isset($data['action']) && $data['action'] === 'signup')) {
        $fullName = isset($data['full_name']) ? trim($data['full_name']) : (isset($data['name']) ? trim($data['name']) : '');
        $email = isset($data['email']) ? trim($data['email']) : '';
        $password = isset($data['password']) ? trim($data['password']) : '';
        $university = isset($data['university']) ? trim($data['university']) : 'University Student';

        if (empty($fullName) || empty($email) || empty($password)) {
            jsonError('Full name, campus email, and password are required.');
        }

        // Check if email already exists
        $checkStmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $checkStmt->execute([$email]);
        if ($checkStmt->fetch()) {
            jsonError('An account with this email address already exists. Please log in.');
        }

        $passwordHash = password_hash($password, PASSWORD_BCRYPT);
        $avatar = 'assets/alex_chen.jpg'; // default avatar

        $insertStmt = $pdo->prepare("
            INSERT INTO users (full_name, email, password_hash, university, tagline, bio, avatar, rating, hours_taught, hours_learned, exchanges_count)
            VALUES (?, ?, ?, ?, ?, ?, ?, 5.0, 0, 0, 0)
        ");
        $tagline = $university . " • Student";
        $bio = "Hello! I just joined Skillverse to learn new skills and share what I know.";
        $insertStmt->execute([$fullName, $email, $passwordHash, $university, $tagline, $bio, $avatar]);
        $newUserId = (int)$pdo->lastInsertId();

        // Seed some starter tags
        $tagInsert = $pdo->prepare("INSERT INTO user_skill_tags (user_id, skill_name, tag_type) VALUES (?, ?, ?)");
        $tagInsert->execute([$newUserId, 'General Tutoring', 'teach']);
        $tagInsert->execute([$newUserId, 'Study Skills', 'learn']);

        // Create welcome notification
        $notifStmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, icon, is_read) VALUES (?, ?, ?, '🎉', 0)");
        $notifStmt->execute([$newUserId, 'Welcome to Skillverse!', 'Your student profile is active. Browse skills or share what you can teach to start exchanging knowledge.']);

        // Set session
        $_SESSION['user_id'] = $newUserId;
        $userProfile = getUserFullProfile($newUserId, $pdo);

        jsonResponse([
            'success' => true,
            'message' => 'Account created successfully! Welcome to Skillverse.',
            'user'    => $userProfile
        ], 201);
    }

    // 3. DEMO LOGIN (Allows instant testing with different accounts)
    if ($action === 'demo_login') {
        $targetId = isset($data['user_id']) ? (int)$data['user_id'] : 1;
        $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
        $stmt->execute([$targetId]);
        $userRow = $stmt->fetch();

        if (!$userRow) {
            jsonError('User not found.');
        }

        $_SESSION['user_id'] = $userRow['id'];
        $userProfile = getUserFullProfile($userRow['id'], $pdo);

        jsonResponse([
            'success' => true,
            'message' => 'Switched to demo user ' . $userProfile['full_name'],
            'user'    => $userProfile
        ]);
    }

    // 4. LOG OUT
    if ($action === 'logout') {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();

        jsonResponse([
            'success' => true,
            'message' => 'Logged out successfully.'
        ]);
    }
}

jsonError('Invalid action or request method.', 405);
