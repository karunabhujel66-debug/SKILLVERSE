<?php
/**
 * Skillverse Dashboard API
 * Aggregates summary data, trending skills, and quick stats for the user dashboard
 */

require_once __DIR__ . '/../config/db.php';

$pdo = getDBConnection();
$userId = getCurrentUserId();

// Fetch trending skills
$trendingStmt = $pdo->query("
    SELECT 
        s.id, s.title, s.category, s.description, s.mastery_level AS masteryLevel,
        s.image, u.full_name AS instructor, u.avatar AS avatar
    FROM skills s
    JOIN users u ON s.user_id = u.id
    ORDER BY s.is_featured DESC, s.id ASC
    LIMIT 4
");
$trending = $trendingStmt->fetchAll();

$userStats = null;
$pendingRequestsCount = 0;
$unreadNotificationsCount = 0;

if ($userId) {
    $userStats = getUserFullProfile($userId, $pdo);

    $reqStmt = $pdo->prepare("SELECT COUNT(*) FROM exchange_requests WHERE receiver_id = ? AND status = 'pending'");
    $reqStmt->execute([$userId]);
    $pendingRequestsCount = (int)$reqStmt->fetchColumn();

    $notifStmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $notifStmt->execute([$userId]);
    $unreadNotificationsCount = (int)$notifStmt->fetchColumn();
}

jsonResponse([
    'success'                  => true,
    'user'                     => $userStats,
    'trending'                 => $trending,
    'pendingRequestsCount'     => $pendingRequestsCount,
    'unreadNotificationsCount' => $unreadNotificationsCount
]);
