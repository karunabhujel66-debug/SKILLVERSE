<?php
/**
 * Skillverse Exchange Requests API
 * Handles Creating, Fetching, Accepting, Scheduling, and Declining Skill Exchange Requests
 */

require_once __DIR__ . '/../config/db.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? trim($_GET['action']) : '';

$userId = requireAuth();

if ($method === 'GET') {
    $tab = isset($_GET['tab']) ? trim($_GET['tab']) : 'all';

    // Fetch incoming requests where current user is receiver
    $query = "
        SELECT 
            r.id,
            r.sender_id,
            r.receiver_id,
            r.target_skill_title AS skill,
            r.offered_skill_title AS offeredSkill,
            r.message,
            r.status,
            r.scheduled_date AS scheduledDate,
            r.scheduled_platform AS scheduledPlatform,
            r.scheduled_notes AS scheduledNotes,
            r.created_at,
            u.full_name AS name,
            u.university AS school,
            u.avatar AS avatar
        FROM exchange_requests r
        JOIN users u ON r.sender_id = u.id
        WHERE r.receiver_id = ?
    ";

    $params = [$userId];

    if ($tab === 'pending') {
        $query .= " AND r.status = 'pending'";
    } elseif ($tab === 'accepted') {
        $query .= " AND r.status = 'accepted'";
    } elseif ($tab === 'declined') {
        $query .= " AND r.status = 'declined'";
    }

    $query .= " ORDER BY r.id DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $requests = $stmt->fetchAll();

    foreach ($requests as &$req) {
        $req['time'] = timeElapsedString($req['created_at']);
    }

    // Also get counts for tabs
    $countsStmt = $pdo->prepare("
        SELECT 
            COUNT(*) AS total,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending,
            SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) AS accepted,
            SUM(CASE WHEN status = 'declined' THEN 1 ELSE 0 END) AS declined
        FROM exchange_requests 
        WHERE receiver_id = ?
    ");
    $countsStmt->execute([$userId]);
    $counts = $countsStmt->fetch();

    jsonResponse([
        'success'  => true,
        'counts'   => [
            'total'    => (int)($counts['total'] ?? 0),
            'pending'  => (int)($counts['pending'] ?? 0),
            'accepted' => (int)($counts['accepted'] ?? 0),
            'declined' => (int)($counts['declined'] ?? 0)
        ],
        'requests' => $requests
    ]);
}

if ($method === 'POST') {
    $data = getRequestData();

    // 1. UPDATE STATUS (Accept / Schedule / Decline / Undo)
    if ($action === 'update_status' || isset($data['action']) && $data['action'] === 'update_status') {
        $reqId = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $newStatus = isset($data['status']) ? trim($data['status']) : 'pending';

        if (!$reqId) {
            jsonError('Request ID is required.');
        }

        // Verify request belongs to current user as receiver
        $findStmt = $pdo->prepare("
            SELECT r.*, sender.full_name AS sender_name, receiver.full_name AS receiver_name 
            FROM exchange_requests r
            JOIN users sender ON r.sender_id = sender.id
            JOIN users receiver ON r.receiver_id = receiver.id
            WHERE r.id = ? AND r.receiver_id = ?
        ");
        $findStmt->execute([$reqId, $userId]);
        $req = $findStmt->fetch();

        if (!$req) {
            jsonError('Exchange request not found or unauthorized.', 404);
        }

        $scheduledDate = isset($data['scheduled_date']) ? trim($data['scheduled_date']) : null;
        $scheduledPlatform = isset($data['scheduled_platform']) ? trim($data['scheduled_platform']) : null;
        $scheduledNotes = isset($data['scheduled_notes']) ? trim($data['scheduled_notes']) : null;

        if ($newStatus === 'accepted') {
            $upd = $pdo->prepare("
                UPDATE exchange_requests 
                SET status = 'accepted', scheduled_date = ?, scheduled_platform = ?, scheduled_notes = ?
                WHERE id = ?
            ");
            $upd->execute([$scheduledDate, $scheduledPlatform, $scheduledNotes, $reqId]);

            // Update user impact stats
            $pdo->prepare("UPDATE users SET exchanges_count = exchanges_count + 1, hours_taught = hours_taught + 1 WHERE id = ?")->execute([$userId]);
            $pdo->prepare("UPDATE users SET exchanges_count = exchanges_count + 1, hours_learned = hours_learned + 1 WHERE id = ?")->execute([$req['sender_id']]);

            // Record in exchanges history for both users
            $hist = $pdo->prepare("INSERT INTO exchanges_history (user_id, partner_id, topic, type) VALUES (?, ?, ?, 'taught')");
            $hist->execute([$userId, $req['sender_id'], $req['target_skill_title']]);
            $hist2 = $pdo->prepare("INSERT INTO exchanges_history (user_id, partner_id, topic, type) VALUES (?, ?, ?, 'learned')");
            $hist2->execute([$req['sender_id'], $userId, $req['target_skill_title']]);

            // Notify the sender
            $platformMsg = $scheduledPlatform ? " on " . $scheduledPlatform : "";
            $pdo->prepare("INSERT INTO notifications (user_id, title, message, icon, is_read) VALUES (?, ?, ?, '🎉', 0)")
                ->execute([
                    $req['sender_id'],
                    'Request Accepted!',
                    "{$req['receiver_name']} accepted your exchange request for '{$req['target_skill_title']}'{$platformMsg}."
                ]);

            jsonResponse([
                'success' => true,
                'message' => "Exchange session with {$req['sender_name']} confirmed!"
            ]);
        } elseif ($newStatus === 'declined') {
            $upd = $pdo->prepare("UPDATE exchange_requests SET status = 'declined' WHERE id = ?");
            $upd->execute([$reqId]);

            jsonResponse([
                'success' => true,
                'message' => "Declined request from {$req['sender_name']}."
            ]);
        } else {
            // Restore to pending (Undo)
            $upd = $pdo->prepare("UPDATE exchange_requests SET status = 'pending' WHERE id = ?");
            $upd->execute([$reqId]);

            jsonResponse([
                'success' => true,
                'message' => "Request restored to pending."
            ]);
        }
    }

    // 2. CREATE NEW EXCHANGE REQUEST
    $targetSkill = isset($data['target_skill']) ? trim($data['target_skill']) : (isset($data['skillTitle']) ? trim($data['skillTitle']) : '');
    $instructorName = isset($data['instructor']) ? trim($data['instructor']) : '';
    $receiverId = isset($data['receiver_id']) ? (int)$data['receiver_id'] : 0;
    $offeredSkill = isset($data['offered_skill']) ? trim($data['offered_skill']) : 'General Peer Exchange';
    $message = isset($data['message']) ? trim($data['message']) : '';

    if (empty($targetSkill)) {
        jsonError('Target skill is required.');
    }

    // Resolve instructor user ID if not explicitly passed
    if (!$receiverId && !empty($instructorName)) {
        $instStmt = $pdo->prepare("SELECT id FROM users WHERE full_name LIKE ? OR email LIKE ? LIMIT 1");
        $instStmt->execute(['%' . $instructorName . '%', '%' . $instructorName . '%']);
        $receiverId = (int)$instStmt->fetchColumn();
    }

    // If still not found, default to user 2 (Sarah Jenkins) for demo realism
    if (!$receiverId) {
        $receiverId = ($userId === 1) ? 2 : 1;
    }

    if ($receiverId === $userId) {
        jsonError('You cannot send a skill exchange request to yourself.');
    }

    if (empty($message)) {
        $message = "Hi! I saw your profile and would love to exchange skills on {$targetSkill}.";
    }

    $insertStmt = $pdo->prepare("
        INSERT INTO exchange_requests (sender_id, receiver_id, target_skill_title, offered_skill_title, message, status)
        VALUES (?, ?, ?, ?, ?, 'pending')
    ");
    $insertStmt->execute([$userId, $receiverId, $targetSkill, $offeredSkill, $message]);
    $reqId = (int)$pdo->lastInsertId();

    // Get current sender user info
    $currentUser = getUserFullProfile($userId, $pdo);

    // Create notification for receiver
    $notifStmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, icon, is_read) VALUES (?, ?, ?, '📨', 0)");
    $notifStmt->execute([
        $receiverId,
        'New Skill Exchange Request',
        "{$currentUser['full_name']} sent you a request to exchange {$offeredSkill} for {$targetSkill}."
    ]);

    jsonResponse([
        'success'    => true,
        'message'    => "Request sent to instructor for {$targetSkill}!",
        'request_id' => $reqId
    ], 201);
}

jsonError('Invalid request method.', 405);
