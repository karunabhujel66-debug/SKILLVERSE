<?php
/**
 * Skillverse Notifications API
 * Handles Fetching User Notifications and Marking Items as Read
 */

require_once __DIR__ . '/../config/db.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? trim($_GET['action']) : '';

$userId = requireAuth();

if ($method === 'GET') {
    // Optional: only return notifications newer than a given ID (for polling efficiency)
    $sinceId = isset($_GET['since_id']) ? (int)$_GET['since_id'] : 0;

    if ($sinceId > 0) {
        $stmt = $pdo->prepare("
            SELECT id, title, message AS text, icon, is_read, created_at 
            FROM notifications 
            WHERE user_id = ? AND id > ?
            ORDER BY id DESC 
            LIMIT 20
        ");
        $stmt->execute([$userId, $sinceId]);
    } else {
        $stmt = $pdo->prepare("
            SELECT id, title, message AS text, icon, is_read, created_at 
            FROM notifications 
            WHERE user_id = ? 
            ORDER BY id DESC 
            LIMIT 20
        ");
        $stmt->execute([$userId]);
    }

    $notifications = $stmt->fetchAll();

    $unreadCount = 0;
    foreach ($notifications as &$n) {
        $n['unread'] = (bool)(!$n['is_read']);
        $n['time'] = timeElapsedString($n['created_at']);
        if ($n['unread']) {
            $unreadCount++;
        }
    }

    jsonResponse([
        'success'       => true,
        'unreadCount'   => $unreadCount,
        'notifications' => $notifications
    ]);
}

if ($method === 'POST') {
    $data = getRequestData();
    $notifId = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

    if ($notifId > 0) {
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
        $stmt->execute([$notifId, $userId]);
    } else {
        // Mark all as read
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
        $stmt->execute([$userId]);
    }

    jsonResponse([
        'success' => true,
        'message' => 'Notifications updated.'
    ]);
}

jsonError('Invalid request method.', 405);
