<?php
/**
 * Skillverse Peer Messaging API
 * Handles Fetching Chat Threads and Sending Real-time Messages
 */

require_once __DIR__ . '/../config/db.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

$userId = requireAuth();

if ($method === 'GET') {
    $partnerId = isset($_GET['partner_id']) ? (int)$_GET['partner_id'] : 0;
    $partnerName = isset($_GET['partner_name']) ? trim($_GET['partner_name']) : '';

    // If partner name is provided, resolve to user ID
    if (!$partnerId && !empty($partnerName)) {
        $uStmt = $pdo->prepare("SELECT id FROM users WHERE full_name LIKE ? OR email LIKE ? LIMIT 1");
        $uStmt->execute(['%' . $partnerName . '%', '%' . $partnerName . '%']);
        $partnerId = (int)$uStmt->fetchColumn();
    }

    // Default to Sarah Jenkins (user 2) if not specified for easy demo chat
    if (!$partnerId) {
        $partnerId = ($userId === 1) ? 2 : 1;
    }

    // Get partner info
    $pInfoStmt = $pdo->prepare("SELECT id, full_name, avatar, tagline FROM users WHERE id = ?");
    $pInfoStmt->execute([$partnerId]);
    $partnerInfo = $pInfoStmt->fetch();

    // Fetch conversation messages
    $msgStmt = $pdo->prepare("
        SELECT 
            id,
            sender_id,
            receiver_id,
            message,
            is_read,
            created_at,
            (CASE WHEN sender_id = ? THEN 'sent' ELSE 'received' END) AS direction
        FROM messages
        WHERE (sender_id = ? AND receiver_id = ?)
           OR (sender_id = ? AND receiver_id = ?)
        ORDER BY id ASC
    ");
    $msgStmt->execute([$userId, $userId, $partnerId, $partnerId, $userId]);
    $messages = $msgStmt->fetchAll();

    // Mark received messages as read
    $pdo->prepare("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?")->execute([$partnerId, $userId]);

    jsonResponse([
        'success'  => true,
        'partner'  => $partnerInfo,
        'messages' => $messages
    ]);
}

if ($method === 'POST') {
    $data = getRequestData();

    $receiverId = isset($data['receiver_id']) ? (int)$data['receiver_id'] : 0;
    $partnerName = isset($data['partner_name']) ? trim($data['partner_name']) : '';
    $text = isset($data['message']) ? trim($data['message']) : (isset($data['text']) ? trim($data['text']) : '');

    if (empty($text)) {
        jsonError('Message text cannot be empty.');
    }

    if (!$receiverId && !empty($partnerName)) {
        $uStmt = $pdo->prepare("SELECT id FROM users WHERE full_name LIKE ? OR email LIKE ? LIMIT 1");
        $uStmt->execute(['%' . $partnerName . '%', '%' . $partnerName . '%']);
        $receiverId = (int)$uStmt->fetchColumn();
    }

    if (!$receiverId) {
        $receiverId = ($userId === 1) ? 2 : 1;
    }

    $insert = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, message, is_read) VALUES (?, ?, ?, 0)");
    $insert->execute([$userId, $receiverId, $text]);
    $msgId = (int)$pdo->lastInsertId();

    $newMsg = [
        'id'          => $msgId,
        'sender_id'   => $userId,
        'receiver_id' => $receiverId,
        'message'     => $text,
        'direction'   => 'sent',
        'created_at'  => date('Y-m-d H:i:s')
    ];

    jsonResponse([
        'success' => true,
        'message' => $newMsg
    ], 201);
}

jsonError('Invalid request method.', 405);
