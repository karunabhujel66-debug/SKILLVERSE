<?php
/**
 * Skillverse Skill Image Upload Handler
 * Handles file upload with validation (jpg, jpeg, png only)
 * Stores in /uploads/ directory with unique filename using time() or unique ID
 */

require_once __DIR__ . '/../config/db.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('POST request required.', 405);
}

$userId = requireAuth();

// Validate file upload
if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    $errorMsg = 'Image is required for skill upload';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_NO_FILE) {
        $errorMsg = 'Image is required for skill upload';
    } elseif (isset($_FILES['image'])) {
        $errorMsg = 'Error uploading file: ' . $_FILES['image']['error'];
    }
    jsonError($errorMsg, 400);
}

$file = $_FILES['image'];
$fileName = $file['name'];
$fileTmp = $file['tmp_name'];
$fileSize = $file['size'];
$fileError = $file['error'];

// Check file extension (only jpg, jpeg, png allowed)
$allowedExtensions = ['jpg', 'jpeg', 'png'];
$fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

if (!in_array($fileExtension, $allowedExtensions)) {
    jsonError('Only JPG, JPEG, and PNG files are allowed.', 400);
}

// Check file size (max 5MB)
$maxFileSize = 5 * 1024 * 1024; // 5MB
if ($fileSize > $maxFileSize) {
    jsonError('File size must not exceed 5MB.', 400);
}

// Create uploads directory if it doesn't exist
$uploadsDir = __DIR__ . '/../uploads/';
if (!is_dir($uploadsDir)) {
    mkdir($uploadsDir, 0755, true);
}

// Generate unique filename using time() and random string
$uniqueId = uniqid('skill_' . $userId . '_' . time() . '_', true);
$newFileName = $uniqueId . '.' . $fileExtension;
$uploadPath = $uploadsDir . $newFileName;

// Move uploaded file to uploads directory
if (!move_uploaded_file($fileTmp, $uploadPath)) {
    jsonError('Failed to save uploaded file.', 500);
}

// Return success with file path
$fileUrl = 'uploads/' . $newFileName;

jsonResponse([
    'success' => true,
    'message' => 'Image uploaded successfully.',
    'file_path' => $fileUrl,
    'file_name' => $newFileName
], 201);
?>
