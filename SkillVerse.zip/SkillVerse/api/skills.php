<?php
/**
 * Skillverse Skills Marketplace & Student Directory API
 * Handles Dynamically Fetching Real Skills, Real Users, Avatars, and Tags directly from MySQL
 */

require_once __DIR__ . '/../config/db.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

function inferCategoryFromTitle($title) {
    $t = strtolower($title);
    if (strpos($t, 'design') !== false || strpos($t, 'figma') !== false || strpos($t, 'canva') !== false || strpos($t, 'ui') !== false || strpos($t, 'ux') !== false || strpos($t, 'wirefram') !== false || strpos($t, 'illustrat') !== false) {
        return 'Design';
    }
    if (strpos($t, 'photo') !== false || strpos($t, 'camera') !== false || strpos($t, 'film') !== false || strpos($t, 'video') !== false || strpos($t, 'darkroom') !== false) {
        return 'Photography';
    }
    if (strpos($t, 'business') !== false || strpos($t, 'excel') !== false || strpos($t, 'macro') !== false || strpos($t, 'analyt') !== false || strpos($t, 'finance') !== false || strpos($t, 'market') !== false || strpos($t, 'sql') !== false) {
        return 'Business';
    }
    if (strpos($t, 'spanish') !== false || strpos($t, 'french') !== false || strpos($t, 'german') !== false || strpos($t, 'lang') !== false || strpos($t, 'english') !== false || strpos($t, 'conversat') !== false) {
        return 'Language';
    }
    if (strpos($t, 'music') !== false || strpos($t, 'audio') !== false || strpos($t, 'guitar') !== false || strpos($t, 'piano') !== false || strpos($t, 'vocal') !== false) {
        return 'Music & Audio';
    }
    return 'Development';
}

function getCategoryImageForCategory($category) {
    $map = [
        'Design'        => 'assets/web_design.jpg',
        'Development'   => 'assets/react_patterns.jpg',
        'Photography'   => 'assets/film_photography.jpg',
        'Business'      => 'assets/data_analytics.jpg',
        'Language'      => 'assets/collab_hero.jpg',
        'Music & Audio' => 'assets/collab_hero.jpg'
    ];
    return $map[$category] ?? 'assets/collab_hero.jpg';
}

if ($method === 'GET') {
    $category = isset($_GET['category']) ? trim($_GET['category']) : 'All';
    $search = isset($_GET['q']) ? trim($_GET['q']) : '';

    // 1. Fetch all marketplace skills with user data
    $query = "
        SELECT 
            s.id,
            s.user_id,
            s.title,
            s.category,
            s.mastery_level AS masteryLevel,
            s.description,
            s.image,
            s.is_featured AS isFeatured,
            s.created_at,
            u.full_name AS instructor,
            u.avatar AS avatar,
            u.rating AS instructorRating,
            u.university AS instructorUniversity,
            u.tagline AS instructorTagline,
            u.bio AS instructorBio,
            u.phone AS instructorPhone,
            u.phone_number AS instructorPhoneNumber,
            u.messenger_username AS instructorMessenger,
            u.instagram_username AS instructorInstagram,
            u.facebook_url AS instructorFacebook
        FROM skills s
        JOIN users u ON s.user_id = u.id
        ORDER BY s.is_featured DESC, s.id DESC
    ";

    $stmt = $pdo->query($query);
    $skills = $stmt->fetchAll();

    // 2. Fetch all user skill tags across all users
    $tagsStmt = $pdo->query("SELECT user_id, skill_name, tag_type FROM user_skill_tags ORDER BY id ASC");
    $allTags = $tagsStmt->fetchAll();

    $userTeachTags = [];
    $userLearnTags = [];
    foreach ($allTags as $tag) {
        $uId = (int)$tag['user_id'];
        $cleanName = rtrim($tag['skill_name'], ' ✓');
        if ($tag['tag_type'] === 'teach') {
            $userTeachTags[$uId][] = $cleanName;
        } else {
            $userLearnTags[$uId][] = $cleanName;
        }
    }

    // 3. Keep track of user+skill pairs already in $skills
    $existingUserSkills = [];
    foreach ($skills as &$skill) {
        $skill['isFeatured'] = (bool)$skill['isFeatured'];
        $uId = (int)$skill['user_id'];
        $cleanTitle = strtolower(trim(rtrim($skill['title'], ' ✓')));
        $existingUserSkills[$uId . '_' . $cleanTitle] = true;
        $skill['skillsTeach'] = $userTeachTags[$uId] ?? [];
        $skill['skillsLearn'] = $userLearnTags[$uId] ?? [];
    }
    unset($skill);

    // 4. Also fetch user profiles and dynamically include any teach tags that are not yet in `skills`
    // This guarantees custom users (like `ronuu` with `Canva` and `testing`) appear on Browse!
    $userStmt = $pdo->query("
        SELECT id, full_name, email, university, tagline, bio, avatar, phone, phone_number, messenger_username, instagram_username, facebook_url, rating, hours_taught, hours_learned, exchanges_count 
        FROM users 
        ORDER BY id DESC
    ");
    $allUsers = $userStmt->fetchAll();

    foreach ($allUsers as $u) {
        $uId = (int)$u['id'];
        $teachTags = $userTeachTags[$uId] ?? [];
        $learnTags = $userLearnTags[$uId] ?? [];

        // If user has teach tags, ensure each is present in Browse
        foreach ($teachTags as $tTag) {
            $cleanTitle = strtolower(trim(rtrim($tTag, ' ✓')));
            if (empty($existingUserSkills[$uId . '_' . $cleanTitle])) {
                $existingUserSkills[$uId . '_' . $cleanTitle] = true;
                $cat = inferCategoryFromTitle($tTag);
                $skills[] = [
                    'id'                   => 'tag_' . $uId . '_' . md5($tTag),
                    'user_id'              => $uId,
                    'title'                => $tTag,
                    'category'             => $cat,
                    'masteryLevel'         => 'Intermediate',
                    'description'          => !empty($u['bio']) ? $u['bio'] : "1-on-1 tutoring and skill sharing on {$tTag}.",
                    'image'                => getCategoryImageForCategory($cat),
                    'isFeatured'           => false,
                    'created_at'           => date('Y-m-d H:i:s'),
                    'instructor'           => $u['full_name'],
                    'avatar'               => !empty($u['avatar']) ? $u['avatar'] : 'assets/alex_chen.jpg',
                    'instructorRating'     => (float)$u['rating'],
                    'instructorUniversity' => $u['university'],
                    'instructorTagline'    => $u['tagline'],
                    'instructorBio'        => $u['bio'],
                    'instructorPhone'      => $u['phone'],
                    'instructorPhoneNumber' => $u['phone_number'],
                    'instructorMessenger'  => $u['messenger_username'],
                    'instructorInstagram'  => $u['instagram_username'],
                    'instructorFacebook'   => $u['facebook_url'],
                    'skillsTeach'          => $teachTags,
                    'skillsLearn'          => $learnTags
                ];
            }
        }
    }

    // 5. Apply filters (Category & Search Query)
    $filtered = [];
    $searchLower = strtolower($search);
    $categoryLower = strtolower($category);

    foreach ($skills as $item) {
        // Category check
        if ($categoryLower !== 'all' && strtolower($item['category']) !== $categoryLower) {
            continue;
        }

        // Search check
        if (!empty($searchLower)) {
            $titleMatch = strpos(strtolower($item['title']), $searchLower) !== false;
            $descMatch = strpos(strtolower($item['description']), $searchLower) !== false;
            $catMatch = strpos(strtolower($item['category']), $searchLower) !== false;
            $instMatch = strpos(strtolower($item['instructor']), $searchLower) !== false;
            $uniMatch = strpos(strtolower($item['instructorUniversity'] ?? ''), $searchLower) !== false;
            
            $tagMatch = false;
            foreach (($item['skillsTeach'] ?? []) as $st) {
                if (strpos(strtolower($st), $searchLower) !== false) {
                    $tagMatch = true;
                    break;
                }
            }

            if (!$titleMatch && !$descMatch && !$catMatch && !$instMatch && !$uniMatch && !$tagMatch) {
                continue;
            }
        }

        $filtered[] = $item;
    }

    jsonResponse([
        'success' => true,
        'count'   => count($filtered),
        'skills'  => $filtered
    ]);
}

if ($method === 'POST') {
    $userId = requireAuth();
    $data = getRequestData();
    $action = isset($_GET['action']) ? trim($_GET['action']) : (isset($data['action']) ? trim($data['action']) : '');

    // 1. UPDATE EXISTING SKILL
    if ($action === 'update') {
        $skillId = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $title = isset($data['title']) ? trim($data['title']) : '';
        $category = isset($data['category']) ? trim($data['category']) : 'Development';
        $mastery = isset($data['masteryLevel']) ? trim($data['masteryLevel']) : (isset($data['mastery_level']) ? trim($data['mastery_level']) : 'Intermediate');
        $description = isset($data['description']) ? trim($data['description']) : '';

        if (!$skillId) {
            jsonError('Skill ID is required for editing.');
        }

        if (empty($title)) {
            jsonError('Skill title is required.');
        }

        // Verify ownership
        $checkStmt = $pdo->prepare("SELECT title FROM skills WHERE id = ? AND user_id = ?");
        $checkStmt->execute([$skillId, $userId]);
        $oldRow = $checkStmt->fetch();

        if (!$oldRow) {
            jsonError('Skill listing not found or permission denied.', 403);
        }

        $oldTitle = $oldRow['title'];
        $image = getCategoryImageForCategory($category);

        $upStmt = $pdo->prepare("
            UPDATE skills 
            SET title = ?, category = ?, mastery_level = ?, description = ?, image = ?
            WHERE id = ? AND user_id = ?
        ");
        $upStmt->execute([$title, $category, $mastery, $description, $image, $skillId, $userId]);

        // Sync old tag in user_skill_tags if changed
        $oldTag = $oldTitle . ' ✓';
        $newTag = $title . ' ✓';
        $pdo->prepare("UPDATE user_skill_tags SET skill_name = ? WHERE user_id = ? AND (skill_name = ? OR skill_name = ?)")
            ->execute([$newTag, $userId, $oldTag, $oldTitle]);

        $updatedProfile = getUserFullProfile($userId, $pdo);

        jsonResponse([
            'success' => true,
            'message' => "Skill '{$title}' updated successfully!",
            'profile' => $updatedProfile
        ]);
    }

    // 2. DELETE SKILL VIA POST
    if ($action === 'delete') {
        $skillId = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $title = isset($data['title']) ? trim($data['title']) : '';

        if ($skillId) {
            $checkStmt = $pdo->prepare("SELECT title FROM skills WHERE id = ? AND user_id = ?");
            $checkStmt->execute([$skillId, $userId]);
            $row = $checkStmt->fetch();
            if ($row) {
                $title = $row['title'];
                $pdo->prepare("DELETE FROM skills WHERE id = ? AND user_id = ?")->execute([$skillId, $userId]);
            }
        }

        if (!empty($title)) {
            $clean = rtrim($title, ' ✓');
            $pdo->prepare("DELETE FROM user_skill_tags WHERE user_id = ? AND (skill_name = ? OR skill_name = ?)")
                ->execute([$userId, $clean, $clean . ' ✓']);
        }

        $updatedProfile = getUserFullProfile($userId, $pdo);

        jsonResponse([
            'success' => true,
            'message' => 'Skill deleted successfully.',
            'profile' => $updatedProfile
        ]);
    }

    // 3. CREATE NEW SKILL
    $title = isset($data['title']) ? trim($data['title']) : '';
    $category = isset($data['category']) ? trim($data['category']) : 'Development';
    $mastery = isset($data['masteryLevel']) ? trim($data['masteryLevel']) : (isset($data['mastery_level']) ? trim($data['mastery_level']) : 'Intermediate');
    $description = isset($data['description']) ? trim($data['description']) : '';
    $image = isset($data['image']) ? trim($data['image']) : '';

    // Validation: Skill title is required
    if (empty($title)) {
        jsonError('Skill title is required.');
    }

    // Validation: Description is required
    if (empty($description)) {
        jsonError('Skill description is required.');
    }

    // Validation: Image is required
    if (empty($image)) {
        jsonError('Image is required for skill upload');
    }

    // Insert skill
    $insertStmt = $pdo->prepare("
        INSERT INTO skills (user_id, title, category, mastery_level, description, image, is_featured)
        VALUES (?, ?, ?, ?, ?, ?, 0)
    ");
    $insertStmt->execute([$userId, $title, $category, $mastery, $description, $image]);
    $newSkillId = (int)$pdo->lastInsertId();

    // Add to user_skill_tags if not already there
    $tagCheck = $pdo->prepare("SELECT id FROM user_skill_tags WHERE user_id = ? AND skill_name = ? AND tag_type = 'teach'");
    $tagCheck->execute([$userId, $title . ' ✓']);
    if (!$tagCheck->fetch()) {
        $tagAdd = $pdo->prepare("INSERT INTO user_skill_tags (user_id, skill_name, tag_type) VALUES (?, ?, 'teach')");
        $tagAdd->execute([$userId, $title . ' ✓']);
    }

    // Fetch the newly created skill with instructor details
    $fetchStmt = $pdo->prepare("
        SELECT 
            s.id, s.user_id, s.title, s.category, s.mastery_level AS masteryLevel,
            s.description, s.image, s.is_featured AS isFeatured, s.created_at,
            u.full_name AS instructor, u.avatar AS avatar
        FROM skills s
        JOIN users u ON s.user_id = u.id
        WHERE s.id = ?
    ");
    $fetchStmt->execute([$newSkillId]);
    $newSkill = $fetchStmt->fetch();
    $newSkill['isFeatured'] = (bool)$newSkill['isFeatured'];

    $updatedProfile = getUserFullProfile($userId, $pdo);

    jsonResponse([
        'success' => true,
        'message' => 'Skill published successfully to marketplace.',
        'skill'   => $newSkill,
        'profile' => $updatedProfile
    ], 201);
}

if ($method === 'DELETE') {
    $userId = requireAuth();
    $skillId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $title = isset($_GET['title']) ? trim($_GET['title']) : '';

    if (!$skillId && empty($title)) {
        jsonError('Skill ID or title required.');
    }

    if ($skillId) {
        $checkStmt = $pdo->prepare("SELECT title FROM skills WHERE id = ? AND user_id = ?");
        $checkStmt->execute([$skillId, $userId]);
        $row = $checkStmt->fetch();
        if ($row) {
            $title = $row['title'];
            $pdo->prepare("DELETE FROM skills WHERE id = ? AND user_id = ?")->execute([$skillId, $userId]);
        }
    }

    if (!empty($title)) {
        $clean = rtrim($title, ' ✓');
        $pdo->prepare("DELETE FROM user_skill_tags WHERE user_id = ? AND (skill_name = ? OR skill_name = ?)")
            ->execute([$userId, $clean, $clean . ' ✓']);
    }

    $updatedProfile = getUserFullProfile($userId, $pdo);

    jsonResponse([
        'success' => true,
        'message' => 'Skill deleted successfully.',
        'profile' => $updatedProfile
    ]);
}

jsonError('Invalid request method.', 405);
