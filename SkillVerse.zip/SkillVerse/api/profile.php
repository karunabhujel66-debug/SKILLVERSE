<?php
/**
 * Skillverse User Profile & Skill Tags API
 * Handles Profile Details, Impact Stats, Skills Teach & Skills Learn Tags
 */

require_once __DIR__ . '/../config/db.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? trim($_GET['action']) : '';

$userId = requireAuth();

if ($method === 'GET') {
    $targetId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : $userId;
    $profile = getUserFullProfile($targetId, $pdo);

    if (!$profile) {
        jsonError('User not found.', 404);
    }

    // Fetch recent exchanges history
    $histStmt = $pdo->prepare("
        SELECT 
            eh.id,
            eh.topic,
            eh.type,
            eh.date_completed,
            u.full_name AS partner_name,
            u.avatar AS partner_avatar
        FROM exchanges_history eh
        JOIN users u ON eh.partner_id = u.id
        WHERE eh.user_id = ?
        ORDER BY eh.date_completed DESC
        LIMIT 6
    ");
    $histStmt->execute([$targetId]);
    $history = $histStmt->fetchAll();

    foreach ($history as &$h) {
        $h['time'] = timeElapsedString($h['date_completed']);
    }
    $profile['recentExchanges'] = $history;

    jsonResponse([
        'success' => true,
        'profile' => $profile
    ]);
}

if ($method === 'POST') {
    $data = getRequestData();

    // 1. UPDATE PROFILE BIO / TAGLINE / NAME / CONTACT INFO
    if ($action === 'update' || (isset($data['action']) && $data['action'] === 'update')) {
        $name = isset($data['name']) ? trim($data['name']) : (isset($data['full_name']) ? trim($data['full_name']) : '');
        $tagline = isset($data['tagline']) ? trim($data['tagline']) : '';
        $bio = isset($data['bio']) ? trim($data['bio']) : '';
        $phone = isset($data['phone']) ? trim($data['phone']) : null;
        $phoneNumber = isset($data['phone_number']) ? trim($data['phone_number']) : null;
        $messengerUsername = isset($data['messenger_username']) ? trim($data['messenger_username']) : null;
        $instagramUsername = isset($data['instagram_username']) ? trim($data['instagram_username']) : null;
        $facebookUrl = isset($data['facebook_url']) ? trim($data['facebook_url']) : (isset($data['facebook']) ? trim($data['facebook']) : null);

        if (empty($name)) {
            jsonError('Full name cannot be empty.');
        }

        $stmt = $pdo->prepare("
            UPDATE users 
            SET full_name = ?, tagline = ?, bio = ?, phone = ?, phone_number = ?, messenger_username = ?, instagram_username = ?, facebook_url = ?
            WHERE id = ?
        ");
        $stmt->execute([$name, $tagline, $bio, $phone, $phoneNumber, $messengerUsername, $instagramUsername, $facebookUrl, $userId]);

        $updatedProfile = getUserFullProfile($userId, $pdo);

        jsonResponse([
            'success' => true,
            'message' => 'Profile updated successfully.',
            'profile' => $updatedProfile
        ]);
    }

    // 2. ADD SKILL TAG (Teach or Learn)
    if ($action === 'add_tag' || (isset($data['action']) && $data['action'] === 'add_tag')) {
        $skillName = isset($data['skill_name']) ? trim($data['skill_name']) : (isset($data['skillName']) ? trim($data['skillName']) : '');
        $type = isset($data['type']) ? trim($data['type']) : 'teach';

        if (empty($skillName)) {
            jsonError('Skill name is required.');
        }

        if ($type === 'teach' && !str_ends_with($skillName, '✓')) {
            $skillName .= ' ✓';
        }

        // Avoid exact duplicates
        $check = $pdo->prepare("SELECT id FROM user_skill_tags WHERE user_id = ? AND skill_name = ? AND tag_type = ?");
        $check->execute([$userId, $skillName, $type]);
        if (!$check->fetch()) {
            $stmt = $pdo->prepare("INSERT INTO user_skill_tags (user_id, skill_name, tag_type) VALUES (?, ?, ?)");
            $stmt->execute([$userId, $skillName, $type]);
        }

        $updatedProfile = getUserFullProfile($userId, $pdo);

        jsonResponse([
            'success' => true,
            'message' => "Added {$skillName} to your profile!",
            'profile' => $updatedProfile
        ]);
    }

    // 2b. EDIT SKILL TAG (Teach or Learn)
    if ($action === 'edit_tag' || (isset($data['action']) && $data['action'] === 'edit_tag')) {
        $oldName = isset($data['old_name']) ? trim($data['old_name']) : (isset($data['oldName']) ? trim($data['oldName']) : '');
        $newName = isset($data['new_name']) ? trim($data['new_name']) : (isset($data['newName']) ? trim($data['newName']) : '');
        $type = isset($data['type']) ? trim($data['type']) : 'teach';

        if (empty($oldName) || empty($newName)) {
            jsonError('Both old and new skill names are required.');
        }

        $cleanOld = rtrim($oldName, ' ✓');
        $cleanNew = rtrim($newName, ' ✓');
        $savedNew = ($type === 'teach') ? $cleanNew . ' ✓' : $cleanNew;

        $pdo->prepare("UPDATE user_skill_tags SET skill_name = ?, tag_type = ? WHERE user_id = ? AND (skill_name = ? OR skill_name = ?)")
            ->execute([$savedNew, $type, $userId, $cleanOld, $cleanOld . ' ✓']);

        $pdo->prepare("UPDATE skills SET title = ? WHERE user_id = ? AND (title = ? OR title = ?)")
            ->execute([$cleanNew, $userId, $cleanOld, $cleanOld . ' ✓']);

        $updatedProfile = getUserFullProfile($userId, $pdo);

        jsonResponse([
            'success' => true,
            'message' => "Updated tag to {$cleanNew}!",
            'profile' => $updatedProfile
        ]);
    }

    // 3. DELETE SKILL TAG
    if ($action === 'delete_tag' || (isset($data['action']) && $data['action'] === 'delete_tag')) {
        $skillName = isset($data['skill_name']) ? trim($data['skill_name']) : (isset($data['skillName']) ? trim($data['skillName']) : '');
        $type = isset($data['type']) ? trim($data['type']) : null;

        if (empty($skillName)) {
            jsonError('Skill name is required.');
        }

        $clean = rtrim($skillName, ' ✓');

        if ($type) {
            $stmt = $pdo->prepare("DELETE FROM user_skill_tags WHERE user_id = ? AND (skill_name = ? OR skill_name = ?) AND tag_type = ?");
            $stmt->execute([$userId, $clean, $clean . ' ✓', $type]);
        } else {
            $stmt = $pdo->prepare("DELETE FROM user_skill_tags WHERE user_id = ? AND (skill_name = ? OR skill_name = ?)");
            $stmt->execute([$userId, $clean, $clean . ' ✓']);
        }

        // Also clean from skills table if it exists
        $pdo->prepare("DELETE FROM skills WHERE user_id = ? AND (title = ? OR title = ?)")
            ->execute([$userId, $clean, $clean . ' ✓']);

        $updatedProfile = getUserFullProfile($userId, $pdo);

        jsonResponse([
            'success' => true,
            'message' => "Removed tag.",
            'profile' => $updatedProfile
        ]);
    }

    // 4. UPLOAD AVATAR (profile picture)
    if ($action === 'upload_avatar') {
        if (empty($_FILES['avatar'])) {
            jsonError('No file uploaded.', 400);
        }

        $file     = $_FILES['avatar'];
        $maxBytes = 5 * 1024 * 1024; // 5 MB

        if ($file['error'] !== UPLOAD_ERR_OK) {
            jsonError('Upload error code: ' . $file['error'], 400);
        }
        if ($file['size'] > $maxBytes) {
            jsonError('File is too large. Maximum allowed size is 5 MB.', 400);
        }

        // Validate MIME type via finfo (not just extension)
        $allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $finfo        = finfo_open(FILEINFO_MIME_TYPE);
        $mime         = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mime, $allowedMimes)) {
            jsonError('Invalid file type. Please upload a JPG, PNG, GIF or WebP image.', 400);
        }

        // Determine extension from validated MIME
        $extMap = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/gif'  => 'gif',
            'image/webp' => 'webp',
        ];
        $ext = $extMap[$mime];

        // Destination directory — relative to the project root
        $uploadDir = __DIR__ . '/../uploads/avatars/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        // Remove old custom avatar file for this user (keep seeded assets)
        $oldStmt = $pdo->prepare("SELECT avatar FROM users WHERE id = ?");
        $oldStmt->execute([$userId]);
        $oldRow = $oldStmt->fetch();
        if ($oldRow && $oldRow['avatar']) {
            $oldAbs = __DIR__ . '/../' . ltrim($oldRow['avatar'], '/');
            if (strpos($oldRow['avatar'], 'uploads/avatars/') !== false && file_exists($oldAbs)) {
                unlink($oldAbs);
            }
        }

        // Unique filename: user_{id}_{timestamp}.{ext}
        $filename  = 'user_' . $userId . '_' . time() . '.' . $ext;
        $destPath  = $uploadDir . $filename;
        $publicUrl = 'uploads/avatars/' . $filename;

        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            jsonError('Failed to save the uploaded file.', 500);
        }

        // Persist to database
        $upStmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
        $upStmt->execute([$publicUrl, $userId]);

        $updatedProfile = getUserFullProfile($userId, $pdo);

        jsonResponse([
            'success' => true,
            'message' => 'Profile picture updated successfully!',
            'avatar'  => $publicUrl,
            'profile' => $updatedProfile,
        ]);
    }
}

jsonError('Invalid request method.', 405);
